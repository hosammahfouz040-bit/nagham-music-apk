import dotenv from "dotenv";
dotenv.config();
import fs from "fs";
import path from "path";
import pg from "pg";
const { Pool } = pg;

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function exportCatalog() {
  console.log("Exporting complete catalog from PostgreSQL to public/data/catalog.json...");

  const dataDir = path.join(process.cwd(), "public", "data");
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  const [tracksRes, artistsRes, albumsRes, playlistsRes] = await Promise.all([
    pool.query(`
      SELECT 
        track_id as "trackId",
        title,
        artist_name as "artistName",
        album_name as "albumName",
        artwork_url as "artworkUrl",
        preview_url as "previewUrl",
        full_stream_url as "fullStreamUrl",
        youtube_video_id as "youtubeVideoId",
        is_full_playable as "isFullPlayable",
        full_duration_seconds as "fullDurationSeconds",
        playback_type as "playbackType",
        duration_seconds as "durationSeconds",
        genre,
        genre_category as "genreCategory",
        language,
        release_date as "releaseDate",
        external_apple_music_url as "externalAppleMusicUrl",
        external_spotify_url as "externalSpotifyUrl",
        external_youtube_url as "externalYoutubeUrl",
        external_anghami_url as "externalAnghamiUrl"
      FROM cached_tracks
      ORDER BY id ASC
    `),
    pool.query(`
      SELECT 
        id,
        name,
        name_ar as "nameAr",
        image_url as "imageUrl",
        bio,
        genre,
        genre_category as "genreCategory",
        language,
        monthly_listeners as "monthlyListeners",
        is_popular as "isPopular"
      FROM artists
      ORDER BY id ASC
    `),
    pool.query(`
      SELECT 
        id,
        title,
        artist_name as "artistName",
        artist_id as "artistId",
        cover_url as "coverUrl",
        release_year as "releaseYear",
        genre,
        genre_category as "genreCategory",
        language,
        total_tracks as "totalTracks"
      FROM albums
      ORDER BY id ASC
    `),
    pool.query(`
      SELECT 
        id,
        name,
        description,
        cover_url as "coverUrl",
        is_system as "isSystem",
        genre_category as "genreCategory"
      FROM playlists
      ORDER BY id ASC
    `),
  ]);

  const catalog = {
    version: "2.0.0",
    exportedAt: new Date().toISOString(),
    totalTracks: tracksRes.rows.length,
    totalArtists: artistsRes.rows.length,
    totalAlbums: albumsRes.rows.length,
    totalPlaylists: playlistsRes.rows.length,
    artists: artistsRes.rows,
    albums: albumsRes.rows,
    playlists: playlistsRes.rows,
    tracks: tracksRes.rows,
  };

  const catalogPath = path.join(dataDir, "catalog.json");
  fs.writeFileSync(catalogPath, JSON.stringify(catalog));
  console.log(`✓ Catalog exported successfully: ${catalogPath} (${(fs.statSync(catalogPath).size / 1024 / 1024).toFixed(2)} MB)`);
  console.log(`  - Tracks: ${catalog.totalTracks}`);
  console.log(`  - Artists: ${catalog.totalArtists}`);
  console.log(`  - Albums: ${catalog.totalAlbums}`);
  console.log(`  - Playlists: ${catalog.totalPlaylists}`);

  pool.end();
}

exportCatalog().catch(console.error);

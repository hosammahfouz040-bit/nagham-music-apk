import fs from "fs";
import path from "path";
import zlib from "zlib";

function createPNG(width, height, r, g, b) {
  // Minimal uncompressed PNG generator
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR chunk
  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData[8] = 8; // 8-bit depth
  ihdrData[9] = 2; // Truecolor (RGB)
  ihdrData[10] = 0; // Deflate compression
  ihdrData[11] = 0; // Filter method
  ihdrData[12] = 0; // No interlace

  const ihdrChunk = createChunk("IHDR", ihdrData);

  // Raw image data with filter byte 0 at start of each scanline
  const rawData = Buffer.alloc(height * (1 + width * 3));
  let offset = 0;

  for (let y = 0; y < height; y++) {
    rawData[offset++] = 0; // Filter byte 0 (None)
    for (let x = 0; x < width; x++) {
      // Calculate gradient and rounded borders
      const dx = x - width / 2;
      const dy = y - height / 2;
      const dist = Math.sqrt(dx * dx + dy * dy);
      const maxDist = width / 2;

      // Emerald to Cyan gradient
      const factor = (x + y) / (width + height);
      let red = Math.round(16 + factor * 10);
      let green = Math.round(185 + factor * 20);
      let blue = Math.round(129 + factor * 80);

      // Darker border
      if (dist > maxDist * 0.95) {
        red = 10;
        green = 10;
        blue = 15;
      }

      rawData[offset++] = Math.min(255, Math.max(0, red));
      rawData[offset++] = Math.min(255, Math.max(0, green));
      rawData[offset++] = Math.min(255, Math.max(0, blue));
    }
  }

  const compressedData = zlib.deflateSync(rawData);
  const idatChunk = createChunk("IDAT", compressedData);
  const iendChunk = createChunk("IEND", Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

function createChunk(type, data) {
  const length = Buffer.alloc(4);
  length.writeUInt32BE(data.length, 0);

  const typeBuffer = Buffer.from(type, "ascii");
  const crcData = Buffer.concat([typeBuffer, data]);
  const crc = crc32(crcData);

  const crcBuffer = Buffer.alloc(4);
  crcBuffer.writeUInt32BE(crc, 0);

  return Buffer.concat([length, typeBuffer, data, crcBuffer]);
}

// CRC32 implementation
function crc32(buf) {
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    const byte = buf[i];
    crc = crc ^ byte;
    for (let j = 0; j < 8; j++) {
      const mask = -(crc & 1);
      crc = (crc >>> 1) ^ (0xedb88320 & mask);
    }
  }
  return (crc ^ 0xffffffff) >>> 0;
}

const iconsDir = path.join(process.cwd(), "public", "icons");
fs.mkdirSync(iconsDir, { recursive: true });

const png192 = createPNG(192, 192, 16, 185, 129);
const png512 = createPNG(512, 512, 16, 185, 129);

fs.writeFileSync(path.join(iconsDir, "icon-192.png"), png192);
fs.writeFileSync(path.join(iconsDir, "icon-512.png"), png512);
fs.writeFileSync(path.join(process.cwd(), "public", "icon-192.png"), png192);
fs.writeFileSync(path.join(process.cwd(), "public", "icon-512.png"), png512);

console.log("✓ PNG icons (192x192 & 512x512) generated successfully!");

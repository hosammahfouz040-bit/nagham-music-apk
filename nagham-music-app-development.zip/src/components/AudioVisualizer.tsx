"use client";

import React from "react";

interface AudioVisualizerProps {
  isPlaying: boolean;
  barCount?: number;
  className?: string;
  color?: string;
}

export function AudioVisualizer({
  isPlaying,
  barCount = 4,
  className = "",
  color = "bg-gradient-to-t from-emerald-500 to-teal-300",
}: AudioVisualizerProps) {
  const bars = Array.from({ length: barCount }, (_, i) => i);

  return (
    <div className={`flex items-end gap-0.5 h-4.5 px-0.5 ${className}`} aria-label="مؤشر تشغيل الصوت">
      {bars.map((barIndex) => {
        const animClasses = ["animate-eq-1", "animate-eq-2", "animate-eq-3", "animate-eq-1", "animate-eq-2"];
        const chosenAnim = animClasses[barIndex % animClasses.length];

        return (
          <span
            key={barIndex}
            style={{
              animationDelay: `${(barIndex * 0.12).toFixed(2)}s`,
            }}
            className={`w-0.5 sm:w-1 rounded-full transition-all duration-300 ${color} ${
              isPlaying ? `${chosenAnim} shadow-sm shadow-emerald-400/40` : "h-1 opacity-40"
            }`}
          />
        );
      })}
    </div>
  );
}

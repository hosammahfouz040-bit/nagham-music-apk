"use client";

import React, { useState } from "react";
import { usePlayer } from "@/context/PlayerContext";
import {
  X,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Shuffle,
  Repeat,
  Heart,
  Volume2,
  VolumeX,
  Moon,
  Gauge,
  ExternalLink,
  ListMusic,
  FileText,
  Disc,
  Clock,
  Sparkles,
  Share2,
  Check,
  Music,
  CheckCircle2,
  AlertCircle,
  Radio,
} from "lucide-react";
import { AudioVisualizer } from "./AudioVisualizer";

export function FullPlayerModal() {
  const {
    currentTrack,
    isPlaying,
    currentTime,
    duration,
    volume,
    isMuted,
    isShuffle,
    repeatMode,
    playbackRate,
    queue,
    queueIndex,
    sleepTimerRemaining,
    isFullPlayerOpen,
    togglePlay,
    nextTrack,
    prevTrack,
    seek,
    setVolumeLevel,
    toggleMute,
    toggleShuffle,
    toggleRepeat,
    setSpeed,
    setSleepTimer,
    toggleFavorite,
    isFavorite,
    closeFullPlayer,
    playTrack,
    removeFromQueue,
  } = usePlayer();

  const [activeTab, setActiveTab] = useState<"player" | "lyrics" | "queue">("player");
  const [showSleepMenu, setShowSleepMenu] = useState(false);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [isVinylMode, setIsVinylMode] = useState(true);

  if (!isFullPlayerOpen || !currentTrack) return null;

  const isFav = isFavorite(currentTrack.trackId);
  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  const formatTime = (seconds: number) => {
    if (!seconds || isNaN(seconds)) return "0:00";
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? "0" : ""}${secs}`;
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator
        .share({
          title: `${currentTrack.title} - ${currentTrack.artistName}`,
          text: `استمع إلى ${currentTrack.title} عبر تطبيق نغم Nagham`,
          url: window.location.href,
        })
        .catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#060608]/96 backdrop-blur-3xl flex flex-col justify-between overflow-y-auto animate-in fade-in duration-300">
      {/* Background ambient glow matching album art */}
      <div
        className="absolute inset-0 opacity-25 pointer-events-none blur-3xl scale-125 transition-all duration-700"
        style={{
          backgroundImage: `radial-gradient(circle at 50% 30%, #10b981 0%, transparent 70%)`,
        }}
      />

      {/* Top Header Bar */}
      <div className="relative z-10 max-w-4xl w-full mx-auto px-4 sm:px-6 pt-5 pb-3 flex items-center justify-between border-b border-white/[0.08]">
        <button
          onClick={closeFullPlayer}
          className="p-2.5 rounded-2xl bg-[#14141c] hover:bg-[#1e1e2c] text-zinc-300 hover:text-white border border-white/[0.08] transition shadow-md"
          title="إغلاق المشغل"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1.5 bg-[#121218] p-1.5 rounded-2xl border border-white/[0.08] text-xs font-bold shadow-lg">
          <button
            onClick={() => setActiveTab("player")}
            className={`px-4 py-2 rounded-xl transition-all duration-200 flex items-center gap-2 ${
              activeTab === "player"
                ? "bg-gradient-to-r from-emerald-500 to-teal-400 text-zinc-950 font-black shadow-md shadow-emerald-500/20"
                : "text-zinc-400 hover:text-white"
            }`}
          >
            <Disc className="w-3.5 h-3.5" />
            <span>المشغل</span>
          </button>
          <button
            onClick={() => setActiveTab("lyrics")}
            className={`px-4 py-2 rounded-xl transition-all duration-200 flex items-center gap-2 ${
              activeTab === "lyrics"
                ? "bg-gradient-to-r from-emerald-500 to-teal-400 text-zinc-950 font-black shadow-md shadow-emerald-500/20"
                : "text-zinc-400 hover:text-white"
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>المصادر الرسمية</span>
          </button>
          <button
            onClick={() => setActiveTab("queue")}
            className={`px-4 py-2 rounded-xl transition-all duration-200 flex items-center gap-2 ${
              activeTab === "queue"
                ? "bg-gradient-to-r from-emerald-500 to-teal-400 text-zinc-950 font-black shadow-md shadow-emerald-500/20"
                : "text-zinc-400 hover:text-white"
            }`}
          >
            <ListMusic className="w-3.5 h-3.5" />
            <span>الانتظار ({queue.length})</span>
          </button>
        </div>

        {/* Share Button */}
        <button
          onClick={handleShare}
          className="p-2.5 rounded-2xl bg-[#14141c] hover:bg-[#1e1e2c] text-zinc-300 hover:text-white border border-white/[0.08] transition shadow-md"
          title="مشاركة الأغنية"
        >
          {copiedLink ? <Check className="w-5 h-5 text-emerald-400" /> : <Share2 className="w-5 h-5" />}
        </button>
      </div>

      {/* Main Body */}
      <div className="relative z-10 max-w-2xl w-full mx-auto px-6 py-4 flex-1 flex flex-col justify-center">
        {activeTab === "player" && (
          <div className="flex flex-col items-center justify-center gap-5">
            {/* Full Track Playback Banner */}
            <div className="flex items-center justify-between w-full p-3 rounded-2xl bg-gradient-to-r from-emerald-950/40 via-[#12121c] to-teal-950/40 border border-emerald-500/30 shadow-lg">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-emerald-500/20 flex items-center justify-center border border-emerald-500/30">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                </div>
                <div className="text-right">
                  <p className="text-xs font-bold text-white">
                    تشغيل الأغنية كاملة (Official Full Stream)
                  </p>
                  <p className="text-[10px] text-zinc-400">
                    استماع كامل من البداية إلى النهاية بدون انقطاع
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/30">
                <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                <span>أغنية كاملة</span>
              </div>
            </div>

            {/* Artwork with Luxury Vinyl turntable toggle */}
            <div className="relative group cursor-pointer my-1" onClick={() => setIsVinylMode(!isVinylMode)}>
              <div
                className={`w-60 h-60 sm:w-72 sm:h-72 rounded-3xl overflow-hidden shadow-2xl border-2 border-white/[0.1] relative transition-all duration-700 ${
                  isVinylMode
                    ? `rounded-full border-8 border-[#12121a] shadow-emerald-500/15 ${
                        isPlaying ? "animate-[spin_16s_linear_infinite]" : ""
                      }`
                    : ""
                }`}
              >
                {currentTrack.artworkUrl ? (
                  <img
                    src={currentTrack.artworkUrl}
                    alt={currentTrack.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-zinc-900 flex items-center justify-center">
                    <Music className="w-16 h-16 text-zinc-600" />
                  </div>
                )}
                {isVinylMode && (
                  <div className="absolute inset-0 m-auto w-16 h-16 rounded-full bg-zinc-950 border-4 border-zinc-800 flex items-center justify-center shadow-inner">
                    <div className="w-4 h-4 rounded-full bg-emerald-400 shadow-md shadow-emerald-400" />
                  </div>
                )}
              </div>
            </div>

            {/* Track Info */}
            <div className="w-full flex items-center justify-between gap-4 mt-1">
              <div className="min-w-0 flex-1 text-right">
                <h1 className="text-xl sm:text-2xl font-black text-white truncate">{currentTrack.title}</h1>
                <p className="text-sm sm:text-base text-zinc-300 font-semibold truncate mt-0.5">{currentTrack.artistName}</p>
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-xs bg-white/[0.06] text-zinc-300 px-3 py-1 rounded-full border border-white/[0.08] font-medium">
                    {currentTrack.genre || "موسيقى"}
                  </span>
                  <span className="text-xs bg-emerald-950/80 text-emerald-300 border border-emerald-600/40 px-3 py-1 rounded-full flex items-center gap-1 font-bold">
                    <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                    أغنية كاملة من البداية للنهاية
                  </span>
                </div>
              </div>

              {/* Favorite Heart Button */}
              <button
                onClick={() => toggleFavorite(currentTrack)}
                className={`p-3.5 rounded-2xl bg-[#14141c] border border-white/[0.08] hover:scale-105 transition shadow-lg ${
                  isFav ? "text-rose-500 border-rose-900/50 bg-rose-950/30" : "text-zinc-400 hover:text-white"
                }`}
                title={isFav ? "إزالة من المفضلة" : "إضافة للمفضلة"}
              >
                <Heart className={`w-6 h-6 ${isFav ? "fill-rose-500 text-rose-500" : ""}`} />
              </button>
            </div>

            {/* Timeline Progress Bar with Glowing Slider */}
            <div className="w-full flex flex-col gap-1.5">
              <input
                type="range"
                min="0"
                max={duration || 240}
                step="0.1"
                value={currentTime}
                onChange={(e) => seek(parseFloat(e.target.value))}
                className="w-full h-2.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
              />
              <div className="flex justify-between text-xs text-zinc-400 font-medium px-1">
                <span>{formatTime(currentTime)}</span>
                <span className="text-[11px] text-emerald-400 font-bold">
                  تشغيل كامل بدون انقطاع
                </span>
                <span>{formatTime(duration)}</span>
              </div>
            </div>

            {/* Playback Controls */}
            <div className="w-full flex items-center justify-between max-w-md my-1">
              {/* Shuffle */}
              <button
                onClick={toggleShuffle}
                className={`p-3 rounded-2xl transition ${
                  isShuffle ? "text-emerald-400 bg-emerald-500/15" : "text-zinc-400 hover:text-white"
                }`}
                title="تشغيل عشوائي"
              >
                <Shuffle className="w-5 h-5" />
              </button>

              {/* Prev */}
              <button
                onClick={prevTrack}
                className="p-3 text-zinc-200 hover:text-white hover:bg-white/[0.06] rounded-2xl transition"
                title="الأغنية السابقة"
              >
                <SkipBack className="w-7 h-7 rtl:rotate-180" />
              </button>

              {/* Big Play/Pause Button */}
              <button
                onClick={togglePlay}
                className="w-16 h-16 sm:w-18 sm:h-18 rounded-3xl bg-gradient-to-tr from-emerald-500 via-teal-400 to-cyan-400 hover:scale-105 active:scale-95 text-zinc-950 flex items-center justify-center shadow-2xl shadow-emerald-500/35 transition-all duration-200"
                title={isPlaying ? "إيقاف مؤقت" : "تشغيل"}
              >
                {isPlaying ? <Pause className="w-8 h-8 fill-zinc-950" /> : <Play className="w-8 h-8 fill-zinc-950 ml-1" />}
              </button>

              {/* Next */}
              <button
                onClick={nextTrack}
                className="p-3 text-zinc-200 hover:text-white hover:bg-white/[0.06] rounded-2xl transition"
                title="الأغنية التالية"
              >
                <SkipForward className="w-7 h-7 rtl:rotate-180" />
              </button>

              {/* Repeat */}
              <button
                onClick={toggleRepeat}
                className={`p-3 rounded-2xl transition relative ${
                  repeatMode !== "off" ? "text-emerald-400 bg-emerald-500/15" : "text-zinc-400 hover:text-white"
                }`}
                title={`وضع التكرار: ${repeatMode}`}
              >
                <Repeat className="w-5 h-5" />
                {repeatMode === "one" && (
                  <span className="absolute top-1.5 right-1.5 text-[10px] font-bold bg-emerald-500 text-zinc-950 rounded-full w-4 h-4 flex items-center justify-center">
                    1
                  </span>
                )}
              </button>
            </div>

            {/* Bottom Utilities: Speed, Sleep Timer, Volume */}
            <div className="w-full flex items-center justify-around border-t border-white/[0.08] pt-3 text-xs text-zinc-400">
              {/* Speed Menu */}
              <div className="relative">
                <button
                  onClick={() => setShowSpeedMenu(!showSpeedMenu)}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#14141c] border border-white/[0.08] hover:text-white transition font-bold"
                >
                  <Gauge className="w-4 h-4 text-emerald-400" />
                  <span>السرعة: {playbackRate}x</span>
                </button>
                {showSpeedMenu && (
                  <div className="absolute bottom-full mb-2 right-0 bg-[#161622] border border-white/[0.1] rounded-2xl p-1.5 shadow-2xl flex flex-col gap-1 z-20 min-w-28">
                    {[0.75, 1.0, 1.25, 1.5, 2.0].map((rate) => (
                      <button
                        key={rate}
                        onClick={() => {
                          setSpeed(rate);
                          setShowSpeedMenu(false);
                        }}
                        className={`px-3 py-1.5 rounded-xl text-right font-bold ${
                          playbackRate === rate ? "bg-emerald-500/20 text-emerald-400" : "hover:bg-white/[0.06]"
                        }`}
                      >
                        {rate}x
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Sleep Timer */}
              <div className="relative">
                <button
                  onClick={() => setShowSleepMenu(!showSleepMenu)}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#14141c] border border-white/[0.08] hover:text-white transition font-bold"
                >
                  <Moon className="w-4 h-4 text-indigo-400" />
                  <span>
                    {sleepTimerRemaining
                      ? `${Math.floor(sleepTimerRemaining / 60)}:${(sleepTimerRemaining % 60)
                          .toString()
                          .padStart(2, "0")}`
                      : "مؤقت النوم"}
                  </span>
                </button>
                {showSleepMenu && (
                  <div className="absolute bottom-full mb-2 left-0 sm:right-0 bg-[#161622] border border-white/[0.1] rounded-2xl p-1.5 shadow-2xl flex flex-col gap-1 z-20 min-w-32">
                    {[
                      { label: "إيقاف المؤقت", val: null },
                      { label: "15 دقيقة", val: 15 },
                      { label: "30 دقيقة", val: 30 },
                      { label: "45 دقيقة", val: 45 },
                      { label: "60 دقيقة", val: 60 },
                    ].map((item, idx) => (
                      <button
                        key={idx}
                        onClick={() => {
                          setSleepTimer(item.val);
                          setShowSleepMenu(false);
                        }}
                        className="px-3 py-1.5 rounded-xl text-right hover:bg-white/[0.06] text-xs font-bold"
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Volume */}
              <div className="flex items-center gap-2">
                <button onClick={toggleMute} className="hover:text-white">
                  {isMuted || volume === 0 ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
                </button>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={isMuted ? 0 : volume}
                  onChange={(e) => setVolumeLevel(parseFloat(e.target.value))}
                  className="w-16 h-1 bg-zinc-800 rounded-lg accent-emerald-500 cursor-pointer"
                />
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Lyrics & Official Sources View */}
        {activeTab === "lyrics" && (
          <div className="flex flex-col gap-4 text-right py-2 overflow-y-auto max-h-[60vh] px-2">
            <div className="bg-[#121218]/90 border border-white/[0.08] p-5 rounded-3xl shadow-xl">
              <h3 className="text-lg font-bold text-white mb-3">معلومات الأغنية والمصدر</h3>
              <div className="grid grid-cols-2 gap-3 text-sm text-zinc-300">
                <div>
                  <span className="text-zinc-500 block text-xs">الأغنية:</span>
                  <span className="font-bold text-white">{currentTrack.title}</span>
                </div>
                <div>
                  <span className="text-zinc-500 block text-xs">المطرب / الفنان:</span>
                  <span className="font-bold text-white">{currentTrack.artistName}</span>
                </div>
                <div>
                  <span className="text-zinc-500 block text-xs">الألبوم:</span>
                  <span className="font-bold text-white">{currentTrack.albumName || "سينجل"}</span>
                </div>
                <div>
                  <span className="text-zinc-500 block text-xs">النوع والتصنيف:</span>
                  <span className="font-bold text-white">{currentTrack.genre || "موسيقى"}</span>
                </div>
                <div>
                  <span className="text-zinc-500 block text-xs">حالة التشغيل الداخلي:</span>
                  <span className="font-bold text-emerald-400">
                    تشغيل كامل من البداية للنهاية
                  </span>
                </div>
                <div>
                  <span className="text-zinc-500 block text-xs">المدة الإجمالية للعمل:</span>
                  <span className="font-bold text-zinc-200">
                    {currentTrack.fullDurationSeconds
                      ? `${Math.floor(currentTrack.fullDurationSeconds / 60)}:${(currentTrack.fullDurationSeconds % 60)
                          .toString()
                          .padStart(2, "0")}`
                      : "أغنية كاملة"}
                  </span>
                </div>
              </div>
            </div>

            {/* Official External Streaming Links */}
            <div className="bg-gradient-to-br from-[#12121a] via-[#161622] to-emerald-950/30 border border-white/[0.08] p-5 rounded-3xl shadow-xl">
              <div className="flex items-center gap-2 mb-3">
                <ExternalLink className="w-5 h-5 text-emerald-400" />
                <h3 className="text-base font-bold text-white">الاستماع للعمل في التطبيقات والخدمات الرسمية</h3>
              </div>
              <p className="text-xs text-zinc-400 mb-4">
                يمكنك الاستماع للأغنية كاملة على تطبيقك الموسيقي المفضل مباشرة:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {/* Spotify */}
                <a
                  href={
                    currentTrack.externalSpotifyUrl ||
                    `https://open.spotify.com/search/${encodeURIComponent(
                      `${currentTrack.artistName} ${currentTrack.title}`
                    )}`
                  }
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between p-3.5 rounded-2xl bg-zinc-900/80 hover:bg-zinc-800 border border-white/[0.08] text-white text-xs font-semibold transition group"
                >
                  <div className="text-right">
                    <span className="block font-bold">Spotify</span>
                    <span className="text-[10px] text-zinc-400 font-normal">استماع كامل</span>
                  </div>
                  <ExternalLink className="w-4 h-4 text-emerald-400" />
                </a>

                {/* Apple Music */}
                {currentTrack.externalAppleMusicUrl && (
                  <a
                    href={currentTrack.externalAppleMusicUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-3.5 rounded-2xl bg-zinc-900/80 hover:bg-zinc-800 border border-white/[0.08] text-white text-xs font-semibold transition group"
                  >
                    <div className="text-right">
                      <span className="block font-bold">Apple Music</span>
                      <span className="text-[10px] text-zinc-400 font-normal">Apple Music</span>
                    </div>
                    <ExternalLink className="w-4 h-4 text-rose-400" />
                  </a>
                )}

                {/* YouTube Music */}
                {currentTrack.externalYoutubeUrl && (
                  <a
                    href={currentTrack.externalYoutubeUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-3.5 rounded-2xl bg-zinc-900/80 hover:bg-zinc-800 border border-white/[0.08] text-white text-xs font-semibold transition group"
                  >
                    <div className="text-right">
                      <span className="block font-bold">YouTube Music / Official</span>
                      <span className="text-[10px] text-zinc-400 font-normal">قناة الفنان الرسمية</span>
                    </div>
                    <ExternalLink className="w-4 h-4 text-red-500" />
                  </a>
                )}

                {/* Anghami */}
                <a
                  href={
                    currentTrack.externalAnghamiUrl ||
                    `https://play.anghami.com/search/${encodeURIComponent(
                      `${currentTrack.artistName} ${currentTrack.title}`
                    )}`
                  }
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between p-3.5 rounded-2xl bg-zinc-900/80 hover:bg-zinc-800 border border-white/[0.08] text-white text-xs font-semibold transition group"
                >
                  <div className="text-right">
                    <span className="block font-bold">أنغامي | Anghami</span>
                    <span className="text-[10px] text-zinc-400 font-normal">أنغامي بلس</span>
                  </div>
                  <ExternalLink className="w-4 h-4 text-purple-400" />
                </a>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Queue Management */}
        {activeTab === "queue" && (
          <div className="flex flex-col gap-3 py-2 overflow-y-auto max-h-[60vh] px-1">
            <div className="flex items-center justify-between px-2 mb-1">
              <span className="text-sm font-bold text-zinc-300">قائمة الانتظار ({queue.length} أغنية)</span>
              <span className="text-xs text-zinc-500 font-medium">انقر لتشغيل أي أغنية</span>
            </div>

            <div className="flex flex-col gap-2">
              {queue.map((track, idx) => {
                const isCurrent = idx === queueIndex;

                return (
                  <div
                    key={`${track.trackId}_${idx}`}
                    className={`flex items-center justify-between p-3 rounded-2xl border transition-all ${
                      isCurrent
                        ? "bg-emerald-500/15 border-emerald-500/40 text-emerald-300 shadow-md shadow-emerald-950/20"
                        : "bg-[#121218]/60 border-white/[0.06] hover:bg-[#1a1a24] text-zinc-300"
                    }`}
                  >
                    <div
                      className="flex items-center gap-3 flex-1 min-w-0 cursor-pointer"
                      onClick={() => playTrack(track, undefined, "full")}
                    >
                      <div className="w-11 h-11 rounded-xl overflow-hidden shrink-0 border border-white/[0.08] relative">
                        {track.artworkUrl ? (
                          <img src={track.artworkUrl} alt={track.title} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full bg-zinc-800" />
                        )}
                        {isCurrent && isPlaying && (
                          <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                            <AudioVisualizer isPlaying={isPlaying} barCount={3} />
                          </div>
                        )}
                      </div>
                      <div className="min-w-0 flex-1 text-right">
                        <div className="flex items-center gap-1.5">
                          <p className={`text-sm font-bold truncate ${isCurrent ? "text-emerald-400 font-bold" : ""}`}>
                            {track.title}
                          </p>
                          <span className="text-[9px] bg-emerald-950 text-emerald-400 px-1.5 py-0.2 rounded font-bold border border-emerald-800/50">
                            كاملة
                          </span>
                        </div>
                        <p className="text-xs text-zinc-400 truncate mt-0.5">{track.artistName}</p>
                      </div>
                    </div>

                    <button
                      onClick={() => removeFromQueue(idx)}
                      className="p-2 text-zinc-500 hover:text-rose-400 rounded-xl hover:bg-white/[0.06] transition mr-2"
                      title="حذف من الانتظار"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Bottom Footer Notice */}
      <div className="relative z-10 max-w-4xl w-full mx-auto px-4 py-3.5 text-center border-t border-white/[0.06]">
        <span className="text-[11px] text-zinc-500 font-medium">
          تطبيق نغم © 2026 • منصة الموسيقى العربية والمصرية الكبرى بأحدث التقنيات
        </span>
      </div>
    </div>
  );
}

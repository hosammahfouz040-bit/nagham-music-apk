"use client";

import React from "react";
import { Track } from "@/lib/types";
import { usePlayer } from "@/context/PlayerContext";
import {
  X,
  Play,
  ExternalLink,
  Sparkles,
  Music,
  CheckCircle2,
  AlertCircle,
  Radio,
  Share2,
} from "lucide-react";

interface ExternalSourceModalProps {
  isOpen: boolean;
  onClose: () => void;
  track: Track | null;
}

export function ExternalSourceModal({ isOpen, onClose, track }: ExternalSourceModalProps) {
  const { playTrack, currentTrack, activeMode } = usePlayer();

  if (!isOpen || !track) return null;

  const isCurrent = currentTrack?.trackId === track.trackId;
  const isFullAvailable = !!(track.youtubeVideoId || track.fullStreamUrl || track.isFullPlayable);

  const handlePlayFullInApp = () => {
    playTrack(track, undefined, "full");
    onClose();
  };

  const handlePlayPreviewInApp = () => {
    playTrack(track, undefined, "preview");
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
      <div className="bg-zinc-900 border border-zinc-800 rounded-3xl w-full max-w-lg p-6 text-right shadow-2xl relative max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 left-5 p-2 rounded-full bg-zinc-800/80 hover:bg-zinc-700 text-zinc-400 hover:text-white transition"
          title="إغلاق"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-start gap-4 mb-5">
          <div className="w-16 h-16 rounded-2xl overflow-hidden shrink-0 border border-zinc-700/60 shadow-lg">
            <img src={track.artworkUrl} alt={track.title} className="w-full h-full object-cover" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-2.5 py-0.5 rounded-full font-bold">
                خيارات الاستماع
              </span>
            </div>
            <h3 className="text-lg font-bold text-white truncate">{track.title}</h3>
            <p className="text-xs text-zinc-400 truncate">{track.artistName}</p>
          </div>
        </div>

        {/* Status Explanation Card */}
        <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 mb-5 flex flex-col gap-2">
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-300">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>تشغيل كامل من البداية إلى النهاية بدون انقطاع</span>
          </div>
          <p className="text-[11px] text-zinc-300 leading-relaxed">
            استمع للأغنية كاملة عبر مشغل نغم المباشر أو افتحها في تطبيقات الموسيقى الأخرى حسب رغبتك.
          </p>
        </div>

        {/* Primary Action Buttons */}
        <div className="flex flex-col gap-2.5 mb-6">
          <button
            onClick={handlePlayFullInApp}
            className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-zinc-950 font-bold text-sm flex items-center justify-center gap-2.5 shadow-lg shadow-emerald-500/25 transition active:scale-98"
          >
            <Play className="w-5 h-5 fill-zinc-950" />
            <span>
              {isCurrent
                ? "جاري تشغيل الأغنية كاملة الآن"
                : `استمع للأغنية كاملة داخل التطبيق (${
                    track.fullDurationSeconds
                      ? `${Math.floor(track.fullDurationSeconds / 60)}:${(track.fullDurationSeconds % 60)
                          .toString()
                          .padStart(2, "0")}`
                      : "نسخة أصلية"
                  })`}
            </span>
          </button>
        </div>

        {/* External Official Music Apps */}
        <div className="flex flex-col gap-3">
          <span className="text-xs font-bold text-zinc-300">أو استمع عبر تطبيقات الموسيقى الرسمية:</span>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            {/* Spotify */}
            <a
              href={
                track.externalSpotifyUrl ||
                `https://open.spotify.com/search/${encodeURIComponent(`${track.artistName} ${track.title}`)}`
              }
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-between p-3 rounded-xl bg-zinc-800/60 hover:bg-zinc-800 border border-zinc-700/50 text-white transition group"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-3 h-3 rounded-full bg-emerald-500" />
                <div className="text-right">
                  <p className="font-bold text-white group-hover:text-emerald-400">Spotify</p>
                  <p className="text-[10px] text-zinc-400">يتطلب تطبيق Spotify / مجاني أو Premium</p>
                </div>
              </div>
              <ExternalLink className="w-4 h-4 text-zinc-400 group-hover:text-emerald-400" />
            </a>

            {/* Apple Music */}
            <a
              href={
                track.externalAppleMusicUrl ||
                `https://music.apple.com/search?term=${encodeURIComponent(`${track.artistName} ${track.title}`)}`
              }
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-between p-3 rounded-xl bg-zinc-800/60 hover:bg-zinc-800 border border-zinc-700/50 text-white transition group"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-3 h-3 rounded-full bg-rose-500" />
                <div className="text-right">
                  <p className="font-bold text-white group-hover:text-rose-400">Apple Music</p>
                  <p className="text-[10px] text-zinc-400">يتطلب اشتراك Apple Music</p>
                </div>
              </div>
              <ExternalLink className="w-4 h-4 text-zinc-400 group-hover:text-rose-400" />
            </a>

            {/* YouTube Music */}
            <a
              href={
                track.externalYoutubeUrl ||
                `https://music.youtube.com/search?q=${encodeURIComponent(`${track.artistName} ${track.title}`)}`
              }
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-between p-3 rounded-xl bg-zinc-800/60 hover:bg-zinc-800 border border-zinc-700/50 text-white transition group"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-3 h-3 rounded-full bg-red-500" />
                <div className="text-right">
                  <p className="font-bold text-white group-hover:text-red-400">YouTube Music</p>
                  <p className="text-[10px] text-zinc-400">استماع رسمي كامل مجاناً</p>
                </div>
              </div>
              <ExternalLink className="w-4 h-4 text-zinc-400 group-hover:text-red-400" />
            </a>

            {/* Anghami */}
            <a
              href={
                track.externalAnghamiUrl ||
                `https://play.anghami.com/search/${encodeURIComponent(`${track.artistName} ${track.title}`)}`
              }
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-between p-3 rounded-xl bg-zinc-800/60 hover:bg-zinc-800 border border-zinc-700/50 text-white transition group"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-3 h-3 rounded-full bg-purple-500" />
                <div className="text-right">
                  <p className="font-bold text-white group-hover:text-purple-400">أنغامي | Anghami</p>
                  <p className="text-[10px] text-zinc-400">استماع عبر أنغامي بلس أو مجاني</p>
                </div>
              </div>
              <ExternalLink className="w-4 h-4 text-zinc-400 group-hover:text-purple-400" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

"use client";

import React from "react";
import Link from "next/link";
import { GENRES } from "@/lib/constants";
import {
  Mic2,
  Flame,
  Sparkles,
  Heart,
  Radio,
  Disc3,
  Music,
  Guitar,
  Coffee,
  Globe,
} from "lucide-react";
import { GenreCategory } from "@/lib/types";

const ICON_MAP: Record<string, React.ElementType> = {
  Mic2,
  Flame,
  Sparkles,
  Heart,
  Radio,
  Disc3,
  Music,
  Guitar,
  Coffee,
  Globe,
};

interface GenreGridProps {
  filterLanguage?: "all" | "arabic" | "international";
  limit?: number;
}

export function GenreGrid({ filterLanguage = "all", limit }: GenreGridProps) {
  let list = GENRES;
  if (filterLanguage !== "all") {
    list = list.filter((g) => g.language === filterLanguage || g.language === "both");
  }
  if (limit) {
    list = list.slice(0, limit);
  }

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4">
      {list.map((genre) => {
        const IconComponent = ICON_MAP[genre.icon] || Music;

        return (
          <Link
            key={genre.id}
            href={`/genres/${genre.id}`}
            className="group relative overflow-hidden rounded-3xl p-4 sm:p-5 border border-white/[0.08] hover:border-white/[0.2] transition-all duration-300 hover:scale-[1.03] hover:shadow-2xl cursor-pointer flex flex-col justify-between min-h-[145px] sm:min-h-[165px]"
            style={{
              background: `linear-gradient(145deg, ${genre.color}25 0%, rgba(14, 14, 20, 0.95) 100%)`,
            }}
          >
            {/* Top Icon & Badge */}
            <div className="flex items-start justify-between relative z-10">
              <div
                className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl flex items-center justify-center shadow-lg transition-transform duration-300 group-hover:scale-110 group-hover:rotate-3"
                style={{ backgroundColor: `${genre.color}35`, color: genre.color, border: `1px solid ${genre.color}50` }}
              >
                <IconComponent className="w-5 h-5" />
              </div>

              <span className="text-[10px] font-bold text-zinc-300 bg-black/40 backdrop-blur-md px-2.5 py-0.5 rounded-full border border-white/[0.08] tracking-wider">
                {genre.language === "arabic" ? "عربي" : genre.language === "international" ? "عالمي" : "شامل"}
              </span>
            </div>

            {/* Bottom Titles */}
            <div className="text-right mt-3 relative z-10">
              <h3 className="text-base sm:text-lg font-black text-white group-hover:text-emerald-300 transition-colors duration-200">
                {genre.title}
              </h3>
              <p className="text-xs text-zinc-400 font-medium line-clamp-1 mt-0.5">{genre.titleEn}</p>
            </div>

            {/* Ambient background glow circle */}
            <div
              className="absolute -bottom-10 -left-10 w-28 h-28 rounded-full opacity-20 group-hover:opacity-40 transition-opacity duration-500 blur-xl pointer-events-none"
              style={{ backgroundColor: genre.color }}
            />
          </Link>
        );
      })}
    </div>
  );
}

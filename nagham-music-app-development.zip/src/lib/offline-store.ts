"use client";

import { Track, Artist, Album, Playlist, GenreCategory, MusicLanguage } from "./types";

const DB_NAME = "NaghamOfflineDB";
const DB_VERSION = 2;

// IndexedDB Helper
function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === "undefined" || !("indexedDB" in window)) {
      return reject(new Error("IndexedDB is not supported"));
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event: any) => {
      const db = event.target.result;

      if (!db.objectStoreNames.contains("tracks")) {
        const trackStore = db.createObjectStore("tracks", { keyPath: "trackId" });
        trackStore.createIndex("artistName", "artistName", { unique: false });
        trackStore.createIndex("genreCategory", "genreCategory", { unique: false });
        trackStore.createIndex("language", "language", { unique: false });
      }

      if (!db.objectStoreNames.contains("artists")) {
        const artistStore = db.createObjectStore("artists", { keyPath: "id" });
        artistStore.createIndex("name", "name", { unique: false });
        artistStore.createIndex("genreCategory", "genreCategory", { unique: false });
      }

      if (!db.objectStoreNames.contains("albums")) {
        const albumStore = db.createObjectStore("albums", { keyPath: "id" });
        albumStore.createIndex("artistName", "artistName", { unique: false });
      }

      if (!db.objectStoreNames.contains("playlists")) {
        db.createObjectStore("playlists", { keyPath: "id" });
      }

      if (!db.objectStoreNames.contains("playlist_items")) {
        const piStore = db.createObjectStore("playlist_items", { keyPath: "id", autoIncrement: true });
        piStore.createIndex("playlistId", "playlistId", { unique: false });
      }

      if (!db.objectStoreNames.contains("favorites")) {
        db.createObjectStore("favorites", { keyPath: "trackId" });
      }

      if (!db.objectStoreNames.contains("history")) {
        const histStore = db.createObjectStore("history", { keyPath: "id", autoIncrement: true });
        histStore.createIndex("playedAt", "playedAt", { unique: false });
      }

      if (!db.objectStoreNames.contains("meta")) {
        db.createObjectStore("meta", { keyPath: "key" });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

// In-memory fallback cache
let memoryCatalog: {
  tracks: Track[];
  artists: Artist[];
  albums: Album[];
  playlists: Playlist[];
} | null = null;

let isSyncing = false;

// Initialize & Sync local IndexedDB from embedded catalog JSON
export async function initializeOfflineDatabase(onProgress?: (percent: number, message: string) => void): Promise<{
  success: boolean;
  totalTracks: number;
  totalArtists: number;
}> {
  if (typeof window === "undefined") {
    return { success: false, totalTracks: 0, totalArtists: 0 };
  }

  if (isSyncing) {
    return { success: true, totalTracks: memoryCatalog?.tracks.length || 0, totalArtists: memoryCatalog?.artists.length || 0 };
  }

  try {
    isSyncing = true;
    const db = await openDB();

    // Check if data already populated
    const countTx = db.transaction("tracks", "readonly");
    const countReq = countTx.objectStore("tracks").count();

    const existingCount = await new Promise<number>((res) => {
      countReq.onsuccess = () => res(countReq.result);
      countReq.onerror = () => res(0);
    });

    if (existingCount >= 2000) {
      console.log(`[OfflineStore] IndexedDB already initialized with ${existingCount} tracks.`);
      isSyncing = false;
      return { success: true, totalTracks: existingCount, totalArtists: 248 };
    }

    if (onProgress) onProgress(10, "جاري تحميل كتالوج الأغاني المحلي...");

    // Fetch the bundled catalog
    const res = await fetch("/data/catalog.json");
    if (!res.ok) throw new Error("Catalog fetch failed");

    const catalog = await res.json();
    if (onProgress) onProgress(40, "جاري حفظ الأغاني في الذاكرة المحلية...");

    // Batch insert into IndexedDB
    const tx = db.transaction(["tracks", "artists", "albums", "playlists", "meta"], "readwrite");
    const trackStore = tx.objectStore("tracks");
    const artistStore = tx.objectStore("artists");
    const albumStore = tx.objectStore("albums");
    const playlistStore = tx.objectStore("playlists");
    const metaStore = tx.objectStore("meta");

    for (const t of catalog.tracks || []) {
      trackStore.put(t);
    }
    for (const a of catalog.artists || []) {
      artistStore.put(a);
    }
    for (const al of catalog.albums || []) {
      albumStore.put(al);
    }
    for (const pl of catalog.playlists || []) {
      playlistStore.put(pl);
    }

    metaStore.put({ key: "version", value: catalog.version, updatedAt: new Date().toISOString() });
    metaStore.put({ key: "totalTracks", value: catalog.totalTracks });

    await new Promise<void>((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });

    memoryCatalog = catalog;
    if (onProgress) onProgress(100, "تمت مزامنة الموسيقى بنجاح!");
    console.log(`[OfflineStore] Successfully populated IndexedDB with ${catalog.totalTracks} tracks.`);

    isSyncing = false;
    return {
      success: true,
      totalTracks: catalog.totalTracks,
      totalArtists: catalog.totalArtists,
    };
  } catch (err: any) {
    console.warn("[OfflineStore] IndexedDB init error, fallback to memory:", err);
    isSyncing = false;
    return { success: false, totalTracks: 0, totalArtists: 0 };
  }
}

// Offline Search across titles, artists, genres
export async function searchOffline(query: string): Promise<{
  tracks: Track[];
  artists: Artist[];
  albums: Album[];
  totalResults: number;
}> {
  const clean = query.trim().toLowerCase();
  if (!clean) {
    return { tracks: [], artists: [], albums: [], totalResults: 0 };
  }

  try {
    const db = await openDB();
    const tx = db.transaction(["tracks", "artists", "albums"], "readonly");
    const trackReq = tx.objectStore("tracks").getAll();
    const artistReq = tx.objectStore("artists").getAll();
    const albumReq = tx.objectStore("albums").getAll();

    const [allTracks, allArtists, allAlbums] = await Promise.all([
      new Promise<Track[]>((res) => { trackReq.onsuccess = () => res(trackReq.result || []); }),
      new Promise<Artist[]>((res) => { artistReq.onsuccess = () => res(artistReq.result || []); }),
      new Promise<Album[]>((res) => { albumReq.onsuccess = () => res(albumReq.result || []); }),
    ]);

    const matchingTracks = allTracks.filter(
      (t) =>
        t.title.toLowerCase().includes(clean) ||
        t.artistName.toLowerCase().includes(clean) ||
        (t.albumName && t.albumName.toLowerCase().includes(clean)) ||
        t.genre.toLowerCase().includes(clean)
    ).slice(0, 50);

    const matchingArtists = allArtists.filter(
      (a) =>
        a.name.toLowerCase().includes(clean) ||
        (a.nameAr && a.nameAr.toLowerCase().includes(clean)) ||
        a.genre.toLowerCase().includes(clean)
    ).slice(0, 15);

    const matchingAlbums = allAlbums.filter(
      (al) =>
        al.title.toLowerCase().includes(clean) ||
        al.artistName.toLowerCase().includes(clean) ||
        al.genre.toLowerCase().includes(clean)
    ).slice(0, 15);

    return {
      tracks: matchingTracks,
      artists: matchingArtists,
      albums: matchingAlbums,
      totalResults: matchingTracks.length + matchingArtists.length + matchingAlbums.length,
    };
  } catch {
    return { tracks: [], artists: [], albums: [], totalResults: 0 };
  }
}

// Get Offline Tracks with filters
export async function getOfflineTracks(options?: {
  genreCategory?: GenreCategory;
  language?: MusicLanguage;
  limit?: number;
}): Promise<Track[]> {
  try {
    const db = await openDB();
    const tx = db.transaction("tracks", "readonly");
    const req = tx.objectStore("tracks").getAll();

    const all = await new Promise<Track[]>((res) => {
      req.onsuccess = () => res(req.result || []);
    });

    let filtered = all;
    if (options?.genreCategory && options.genreCategory !== "all") {
      filtered = filtered.filter((t) => t.genreCategory === options.genreCategory);
    }
    if (options?.language && options.language !== "all") {
      filtered = filtered.filter((t) => t.language === options.language);
    }

    return filtered.slice(0, options?.limit || 50);
  } catch {
    return [];
  }
}

// Get Offline Artists
export async function getOfflineArtists(options?: {
  genreCategory?: GenreCategory;
  language?: MusicLanguage;
  limit?: number;
}): Promise<Artist[]> {
  try {
    const db = await openDB();
    const tx = db.transaction("artists", "readonly");
    const req = tx.objectStore("artists").getAll();

    const all = await new Promise<Artist[]>((res) => {
      req.onsuccess = () => res(req.result || []);
    });

    let filtered = all;
    if (options?.genreCategory && options.genreCategory !== "all") {
      filtered = filtered.filter((a) => a.genreCategory === options.genreCategory);
    }
    if (options?.language && options.language !== "all") {
      filtered = filtered.filter((a) => a.language === options.language);
    }

    return filtered.slice(0, options?.limit || 50);
  } catch {
    return [];
  }
}

// Get Offline Albums
export async function getOfflineAlbums(options?: {
  genreCategory?: GenreCategory;
  language?: MusicLanguage;
  limit?: number;
}): Promise<Album[]> {
  try {
    const db = await openDB();
    const tx = db.transaction("albums", "readonly");
    const req = tx.objectStore("albums").getAll();

    const all = await new Promise<Album[]>((res) => {
      req.onsuccess = () => res(req.result || []);
    });

    let filtered = all;
    if (options?.genreCategory && options.genreCategory !== "all") {
      filtered = filtered.filter((a) => a.genreCategory === options.genreCategory);
    }
    if (options?.language && options.language !== "all") {
      filtered = filtered.filter((a) => a.language === options.language);
    }

    return filtered.slice(0, options?.limit || 50);
  } catch {
    return [];
  }
}

// Offline Favorites Operations
export async function getOfflineFavorites(): Promise<Track[]> {
  try {
    const db = await openDB();
    const tx = db.transaction("favorites", "readonly");
    const req = tx.objectStore("favorites").getAll();
    return await new Promise<Track[]>((res) => {
      req.onsuccess = () => res(req.result || []);
    });
  } catch {
    return [];
  }
}

export async function toggleOfflineFavorite(track: Track): Promise<boolean> {
  try {
    const db = await openDB();
    const tx = db.transaction("favorites", "readwrite");
    const store = tx.objectStore("favorites");
    const getReq = store.get(track.trackId);

    const exists = await new Promise<any>((res) => {
      getReq.onsuccess = () => res(getReq.result);
    });

    if (exists) {
      store.delete(track.trackId);
      return false;
    } else {
      store.put(track);
      return true;
    }
  } catch {
    return false;
  }
}

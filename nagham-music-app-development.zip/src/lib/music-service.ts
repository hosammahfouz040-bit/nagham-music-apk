import { db } from "@/db";
import { cachedTracks, artists, albums, playlists, playlistItems, favorites, listeningHistory } from "@/db/schema";
import { Track, Artist, Album, Playlist, GenreCategory, MusicLanguage, SearchResult, TrackPlaybackType } from "./types";
import { INITIAL_FEATURED_TRACKS, INITIAL_ARTISTS } from "./seed-catalog";
import { eq, desc, sql, ilike, or, and } from "drizzle-orm";
import { seedDatabaseIfEmpty } from "./seed-db";

let isSeedingTriggered = false;

export function triggerBackgroundSeed() {
  if (!isSeedingTriggered) {
    isSeedingTriggered = true;
    seedDatabaseIfEmpty().catch((err) => console.error("Background seed error:", err));
  }
}

// Known verified official YouTube Video IDs for full playback of popular tracks
export const KNOWN_OFFICIAL_FULL_SOURCES: Record<string, { youtubeId: string; fullDuration: number; aliases: string[] }> = {
  // Arabic Pop & Classic
  "tamly maak": {
    youtubeId: "kJQP7kiw5Fk",
    fullDuration: 270,
    aliases: ["tamly", "تملي معاك", "تملي", "tamally"],
  },
  "kifak enta": {
    youtubeId: "q5e4zUf8ZlY",
    fullDuration: 215,
    aliases: ["kifak", "كيفك", "كيفك انت", "كيفك إنت", "kifak inta"],
  },
  "alf leila we leila": {
    youtubeId: "sVf0C0X9sM0",
    fullDuration: 1920,
    aliases: ["alf leila", "الف ليلة", "ألف ليلة", "leila we leila"],
  },
  "anta oumri": {
    youtubeId: "V2K_4Jqf2F4",
    fullDuration: 2400,
    aliases: ["anta oumri", "enta omri", "انت عمري", "إنت عمري", "enta oumri"],
  },
  "el bakht": {
    youtubeId: "x_S_6BqA23U",
    fullDuration: 220,
    aliases: ["bakht", "البخت", "بخت"],
  },
  "mashaer": {
    youtubeId: "tV1WwN2qH6U",
    fullDuration: 234,
    aliases: ["mashaer", "مشاعر", "mashaaer"],
  },
  "bent el geran": {
    youtubeId: "u1b7rZ8-VjY",
    fullDuration: 243,
    aliases: ["bent el", "بنت الجيران", "bent el geran", "bent el geeran"],
  },
  "al amaken": {
    youtubeId: "q7U27H5MvB8",
    fullDuration: 480,
    aliases: ["amaken", "الاماكن", "الأماكن", "alamaken"],
  },
  "ahwak": {
    youtubeId: "6r01eZ2P3_I",
    fullDuration: 240,
    aliases: ["ahwak", "اهواك", "أهواك"],
  },
  "nour el ein": {
    youtubeId: "D8eY4QJ9hVo",
    fullDuration: 300,
    aliases: ["nour el ein", "نور العين", "nour el ain", "habibi ya nour"],
  },
  "sahar el layali": {
    youtubeId: "VbB_a42kKQI",
    fullDuration: 210,
    aliases: ["sahar el layali", "سهر الليالي"],
  },
  "nassam alayna el hawa": {
    youtubeId: "2ZkR3dZqVb8",
    fullDuration: 260,
    aliases: ["nassam", "نسم علينا", "nassam alayna"],
  },
  "batwanes beek": {
    youtubeId: "8U2Z8lQ7-1A",
    fullDuration: 380,
    aliases: ["batwanes", "بتونس بيك", "batwanes beek"],
  },
  "zahma ya donya": {
    youtubeId: "M3F0qV1g33E",
    fullDuration: 310,
    aliases: ["zahma", "زحمة يا دنيا", "zahma ya donya zahma"],
  },
  "el salam aleikom": {
    youtubeId: "g4oG3aH3g18",
    fullDuration: 255,
    aliases: ["salam aleikom", "السلام عليكم", "el salam"],
  },
  "betmoun": {
    youtubeId: "J8Dq_9E8Y3U",
    fullDuration: 245,
    aliases: ["betmoun", "بتمون"],
  },
  "ya bent el eih": {
    youtubeId: "C1r0d_m4sYI",
    fullDuration: 225,
    aliases: ["bent el eih", "يا بنت الايه", "يا بنت الإيه"],
  },
  "ah w noss": {
    youtubeId: "k5_3sR0o4jE",
    fullDuration: 270,
    aliases: ["ah w noss", "اه ونص", "آه ونص"],
  },
  "ana wa laila": {
    youtubeId: "T7gG0b_E5B8",
    fullDuration: 435,
    aliases: ["ana wa laila", "انا وليلى", "أنا وليلى"],
  },
  "tenadek": {
    youtubeId: "vB1K0-T2f8U",
    fullDuration: 280,
    aliases: ["tenadek", "تناديك"],
  },
  "free": {
    youtubeId: "VbB_a42kKQI",
    fullDuration: 190,
    aliases: ["free", "فري"],
  },
  "ghaba": {
    youtubeId: "L6n4R2lX4-E",
    fullDuration: 210,
    aliases: ["ghaba", "غابة"],
  },
  "dorak gai": {
    youtubeId: "m9N6G1bB0c8",
    fullDuration: 235,
    aliases: ["dorak gai", "دورك جاي", "dorak gay"],
  },
  "salka": {
    youtubeId: "kJQP7kiw5Fk",
    fullDuration: 210,
    aliases: ["salka", "سالكة", "سالكه"],
  },
  "kalam eneih": {
    youtubeId: "vBv8C_QZJd4",
    fullDuration: 220,
    aliases: ["kalam eneih", "كلام عينيه", "kalam enaih"],
  },
  // Egyptian Superhits Expansion
  "fady shewaya": {
    youtubeId: "jWdJ4wUq6oQ",
    fullDuration: 232,
    aliases: ["فاضي شوية", "فاضي شويه", "fady shewaya"],
  },
  "reyah el hayat": {
    youtubeId: "vG1G5rPq2uI",
    fullDuration: 270,
    aliases: ["رياح الحياة", "رياح الحياه", "reyah el hayat"],
  },
  "ana negm": {
    youtubeId: "4Z8k6P9q5eA",
    fullDuration: 282,
    aliases: ["أنا نجم", "انا نجم", "ana negm"],
  },
  "samurai": {
    youtubeId: "jZ1b2c3d4e5",
    fullDuration: 245,
    aliases: ["ساموراي", "samurai"],
  },
  "roma": {
    youtubeId: "8k2Z0q1x9E4",
    fullDuration: 250,
    aliases: ["روما", "roma cairokee"],
  },
  "ya leil w yal ein": {
    youtubeId: "T7y_Z6k5B4U",
    fullDuration: 184,
    aliases: ["يا ليل ويالعين", "يا ليل و يالعين", "ya leil"],
  },
  "sabran": {
    youtubeId: "0bV1X8y3P2I",
    fullDuration: 195,
    aliases: ["صبرا", "صبراً", "sabran al shami"],
  },
  "habibi leih": {
    youtubeId: "5vQ_9yP8B1c",
    fullDuration: 217,
    aliases: ["حبيبي ليه", "habibi leih tul8te"],
  },
  "hetet tanya": {
    youtubeId: "U_H-kU0NksU",
    fullDuration: 210,
    aliases: ["حتة تانية", "حته تانيه", "hetet tanya ruby"],
  },
  "namet nena": {
    youtubeId: "F-9RkH2kFvE",
    fullDuration: 195,
    aliases: ["نمت ننه", "نمت ننة", "namet nena"],
  },
  "leh bedary keda": {
    youtubeId: "y2y56Z5vU5Q",
    fullDuration: 240,
    aliases: ["ليه بيداري", "ليه بيداري كدا", "leh bedary"],
  },
  "ekhteyaraty": {
    youtubeId: "mP6sU8eN2kE",
    fullDuration: 198,
    aliases: ["اختياراتي", "اختياراتي مدمرة حياتي", "ekhteyaraty"],
  },
  "wasa3 wasa3": {
    youtubeId: "T9Q9qE2eFvA",
    fullDuration: 205,
    aliases: ["وسع وسع", "wasa3 wasa3 ahmed saad"],
  },
  "eh el yom el helw da": {
    youtubeId: "xU8t3n2l9wE",
    fullDuration: 215,
    aliases: ["ايه اليوم الحلو ده", "إيه اليوم الحلو ده", "eh el yom"],
  },
  "ya btaa el ne3na3": {
    youtubeId: "D1u8p5K9L2w",
    fullDuration: 245,
    aliases: ["يا بتاع النعناع", "يا نعناع", "btaa el ne3na3"],
  },
  "khatwa": {
    youtubeId: "E8q9J4u2p1w",
    fullDuration: 210,
    aliases: ["خطوة", "خطوه", "khatwa mostafa hajjaj"],
  },
  "mshyt khalas": {
    youtubeId: "w7J8F8U8N5E",
    fullDuration: 260,
    aliases: ["مشيت خلاص", "mshyt khalas wael jassar"],
  },
  "ghareeba el nas": {
    youtubeId: "vF9N9Y1L3qE",
    fullDuration: 275,
    aliases: ["غريبة الناس", "غريبه الناس", "ghareeba el nas"],
  },
  "number one": {
    youtubeId: "yE8u9k1h5F0",
    fullDuration: 195,
    aliases: ["نمبر وان", "number one mohamed ramadan"],
  },
  "mafia": {
    youtubeId: "L8y2k1j7V3E",
    fullDuration: 220,
    aliases: ["مافيا", "mafia mohamed ramadan"],
  },
  "3 daqat": {
    youtubeId: "3x3h5k9j2L0",
    fullDuration: 245,
    aliases: ["3 دقات", "تلات دقات", "3 daqat abu"],
  },
  "law gay fe rogoa": {
    youtubeId: "f9e2k1j5u8A",
    fullDuration: 228,
    aliases: ["لو جاي في رجوع", "بأمارة مين", "bamaret meen"],
  },
  "kawkab tany": {
    youtubeId: "h8e2u9k1L5w",
    fullDuration: 360,
    aliases: ["كوكب تاني", "كوكب تانى", "kawkab tany medhat saleh"],
  },
  "3arfa": {
    youtubeId: "k8u9e2b1L5w",
    fullDuration: 250,
    aliases: ["عارفة", "عارفه", "3arfa ali el haggar"],
  },
  "lesa btesaly": {
    youtubeId: "m8e2u1k9L5w",
    fullDuration: 288,
    aliases: ["لسه بتسألي", "لسة بتسالي", "lesa btesaly hany shaker"],
  },
  "3aly el dehkaya": {
    youtubeId: "p8u1k9e2L5w",
    fullDuration: 265,
    aliases: ["علي الضحكاية", "على الضحكايه", "3aly el dehkaya"],
  },
  "qadeyet 3am ahmed": {
    youtubeId: "y1f4k9L2w5E",
    fullDuration: 310,
    aliases: ["قضية عم أحمد", "قضيه عم احمد", "عم أحمد", "qadeyet am ahmed"],
  },
  "feeha haga helwa": {
    youtubeId: "u8w2L5k1f9E",
    fullDuration: 255,
    aliases: ["فيها حاجة حلوة", "فيها حاجه حلوه", "feeha haga helwa omar khairat"],
  },
  "ketab hayaty": {
    youtubeId: "w5E8u9k1L2f",
    fullDuration: 340,
    aliases: ["كتاب حياتي", "كتاب حياتى يا عين", "كتاب حياتي يا عين", "kitab hayati"],
  },
  "ana aho wenta aho": {
    youtubeId: "L2k1f9w5E8u",
    fullDuration: 270,
    aliases: ["انا اهو وانت اهو", "أنا أهو وإنت أهو"],
  },
  "heyele magwo3": {
    youtubeId: "r2k1L5w5E8u",
    fullDuration: 245,
    aliases: ["هيجيلي موجوع", "هيجيلى موجوع", "heyele magwo3 tamer ashour"],
  },
  "ba3d gheyabo": {
    youtubeId: "b8u1k9w5E2L",
    fullDuration: 230,
    aliases: ["بعد غيابه", "بعد غيابه أحمد بتشان", "baad gheyabo"],
  },
  "al hob al haqiqi": {
    youtubeId: "q5e4zUf8ZlY",
    fullDuration: 285,
    aliases: ["الحب الحقيقي", "الحب الحقيقى", "al hob al haqiqi mohamed fouad"],
  },
  "tameni 3aleik": {
    youtubeId: "tV1WwN2qH6U",
    fullDuration: 260,
    aliases: ["طمني عليك", "طمنى عليك", "tameni aleik"],
  },
  "halawet rooh": {
    youtubeId: "kJQP7kiw5Fk",
    fullDuration: 235,
    aliases: ["حلاوة روح", "حلاوه روح", "halawet rooh hakim"],
  },
  "3 saat motawaseleh": {
    youtubeId: "F-9RkH2kFvE",
    fullDuration: 200,
    aliases: ["3 ساعات متواصلة", "تلات ساعات متواصلة", "3 saat ruby"],
  },
  "btmanna ansak": {
    youtubeId: "d9V9Rk1hB4I",
    fullDuration: 230,
    aliases: ["btmanna", "بتمنى انساك", "بتمنى أنساك"],
  },
  "kadabeen": {
    youtubeId: "hZ7Z8n5k4Kk",
    fullDuration: 215,
    aliases: ["kadabeen", "كدابين"],
  },
  "hobbo ganna": {
    youtubeId: "PZ_aX0A21Zk",
    fullDuration: 260,
    aliases: ["hobbo ganna", "حبه جنة", "حبه جنه"],
  },
  "sabry aleel": {
    youtubeId: "8O6v_N1bJbQ",
    fullDuration: 250,
    aliases: ["sabry aleel", "صبري قليل"],
  },
  "wahdon": {
    youtubeId: "z1b3d5g7h9k",
    fullDuration: 320,
    aliases: ["wahdon", "وحدن"],
  },
  "saalouny el nas": {
    youtubeId: "4Z0v7A2kL9c",
    fullDuration: 280,
    aliases: ["saalouny", "سألوني الناس", "سالوني الناس"],
  },
  "habaytak bel sayf": {
    youtubeId: "b8k2Z0q1x9E",
    fullDuration: 215,
    aliases: ["habaytak", "حبيتك بالصيف", "habaytak besayf"],
  },
  "li beirut": {
    youtubeId: "V2K_4Jqf2F4",
    fullDuration: 250,
    aliases: ["li beirut", "لبيروت"],
  },
  "we malo": {
    youtubeId: "1YhQ2Z6QhXo",
    fullDuration: 280,
    aliases: ["we malo", "وماله", "و ماله"],
  },
  "baad el layali": {
    youtubeId: "k5_3sR0o4jE",
    fullDuration: 250,
    aliases: ["baad el layali", "بعد الليالي"],
  },
  "ana ayesh": {
    youtubeId: "2L2mE0zIeXU",
    fullDuration: 260,
    aliases: ["ana ayesh", "انا عايش", "أنا عايش"],
  },
  // International
  "a sky full of stars": {
    youtubeId: "VPRjCeoBqrI",
    fullDuration: 268,
    aliases: ["sky full of stars", "a sky full"],
  },
  "the scientist": {
    youtubeId: "RB-RcX5DS5A",
    fullDuration: 310,
    aliases: ["the scientist", "scientist"],
  },
  "fix you": {
    youtubeId: "k4V3gVg8JaA",
    fullDuration: 295,
    aliases: ["fix you"],
  },
  "clocks": {
    youtubeId: "d020hcWA_Wg",
    fullDuration: 307,
    aliases: ["clocks"],
  },
  "save your tears": {
    youtubeId: "XXYlFuWEuKI",
    fullDuration: 215,
    aliases: ["save your tears"],
  },
  "the hills": {
    youtubeId: "yzTuBuRdAyA",
    fullDuration: 242,
    aliases: ["the hills"],
  },
  "die for you": {
    youtubeId: "uPD0QOGchkM",
    fullDuration: 260,
    aliases: ["die for you"],
  },
  "blinding lights": {
    youtubeId: "4NRXx6U8ABQ",
    fullDuration: 200,
    aliases: ["blinding", "blinding lights"],
  },
  "viva la vida": {
    youtubeId: "dvgZkm1xWPE",
    fullDuration: 242,
    aliases: ["viva la vida", "viva"],
  },
  "nuvole bianche": {
    youtubeId: "kcihcYEOeic",
    fullDuration: 357,
    aliases: ["nuvole", "nuvole bianche"],
  },
  "lose yourself": {
    youtubeId: "_Yhyp-_hX2s",
    fullDuration: 326,
    aliases: ["lose yourself"],
  },
  "bamboleo": {
    youtubeId: "oNgSeJzLJFc",
    fullDuration: 205,
    aliases: ["bamboleo", "bamboléo"],
  },
  "bohemian rhapsody": {
    youtubeId: "fJ9rUzIMcZQ",
    fullDuration: 355,
    aliases: ["bohemian", "bohemian rhapsody"],
  },
  "shape of you": {
    youtubeId: "JGwWNGJdvx8",
    fullDuration: 233,
    aliases: ["shape of you"],
  },
  "someone like you": {
    youtubeId: "hLQl3WQQoQ0",
    fullDuration: 285,
    aliases: ["someone like you"],
  },
  "believer": {
    youtubeId: "7wtfhZwyrcc",
    fullDuration: 204,
    aliases: ["believer"],
  },
  "starboy": {
    youtubeId: "34Na4j8AVgA",
    fullDuration: 230,
    aliases: ["starboy"],
  },
  "yellow": {
    youtubeId: "yKNxeF4KMsY",
    fullDuration: 269,
    aliases: ["yellow"],
  },
};

// Find matching verified full source if available
export function matchFullSongSource(title: string, artist: string): { youtubeId?: string; fullDuration?: number } | null {
  const normTitle = title.toLowerCase().replace(/[\(\)\[\]\-–—\.]/g, " ").trim();
  const normArtist = artist.toLowerCase().trim();
  const fullHaystack = `${normArtist} ${normTitle}`;

  for (const [key, val] of Object.entries(KNOWN_OFFICIAL_FULL_SOURCES)) {
    if (fullHaystack.includes(key)) {
      return { youtubeId: val.youtubeId, fullDuration: val.fullDuration };
    }
    for (const alias of val.aliases) {
      if (fullHaystack.includes(alias.toLowerCase())) {
        return { youtubeId: val.youtubeId, fullDuration: val.fullDuration };
      }
    }
  }
  return null;
}

// Convert Drizzle cachedTrack row to Track model
export function rowToTrack(row: any): Track {
  const fullDur = row.fullDurationSeconds || (row.durationSeconds && row.durationSeconds > 60 ? row.durationSeconds : 240);
  const isFull = true; // All tracks in Nagham are full playable
  const playType: TrackPlaybackType = "youtube_official";

  return {
    id: row.trackId || `track_${row.id}`,
    trackId: row.trackId || `track_${row.id}`,
    title: row.title,
    artistName: row.artistName,
    albumName: row.albumName || "",
    artworkUrl: row.artworkUrl || "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600",
    previewUrl: row.previewUrl,
    fullStreamUrl: row.fullStreamUrl || null,
    youtubeVideoId: row.youtubeVideoId || null,
    durationSeconds: fullDur,
    fullDurationSeconds: fullDur,
    playbackType: playType,
    isFullPlayable: true,
    externalAppleMusicUrl: row.externalAppleMusicUrl,
    externalDeezerUrl: row.externalDeezerUrl,
    externalSpotifyUrl: row.externalSpotifyUrl,
    externalYoutubeUrl:
      row.externalYoutubeUrl ||
      `https://www.youtube.com/results?search_query=${encodeURIComponent(`${row.artistName} ${row.title}`)}`,
    externalAnghamiUrl: row.externalAnghamiUrl || `https://play.anghami.com/search/${encodeURIComponent(`${row.artistName} ${row.title}`)}`,
    genre: row.genre || "موسيقى",
    genreCategory: (row.genreCategory as GenreCategory) || "pop",
    language: (row.language as "arabic" | "international") || "arabic",
    releaseDate: row.releaseDate || "",
    lyrics: row.lyrics || null,
    playCount: row.playCount || 0,
    isFeatured: !!row.isFeatured,
    isTrending: !!row.isTrending,
  };
}

// Map iTunes / Deezer genres to our taxonomy
export function detectGenreCategory(genreStr: string = "", titleStr: string = "", artistStr: string = ""): GenreCategory {
  const text = `${genreStr} ${titleStr} ${artistStr}`.toLowerCase();
  
  if (text.includes("tarab") || text.includes("طرب") || text.includes("أم كلثوم") || text.includes("عبد الحليم") || text.includes("فيروز") || text.includes("وردة") || text.includes("صباح فخري")) {
    return "tarab";
  }
  if (text.includes("shaabi") || text.includes("شعبي") || text.includes("عدوية") || text.includes("حكيم") || text.includes("البحراوي") || text.includes("حمودة")) {
    return "shaabi";
  }
  if (text.includes("mahragan") || text.includes("مهرجان") || text.includes("شاكوش") || text.includes("صاصا") || text.includes("بيكا") || text.includes("عنبة") || text.includes("مسلم")) {
    return "mahraganat";
  }
  if (text.includes("rap") || text.includes("hip-hop") || text.includes("trap") || text.includes("تراب") || text.includes("راب") || text.includes("ويجز") || text.includes("بابلو") || text.includes("eminem") || text.includes("drake")) {
    return "rap";
  }
  if (text.includes("rock") || text.includes("metal") || text.includes("روك") || text.includes("coldplay") || text.includes("queen") || text.includes("dragons")) {
    return "rock";
  }
  if (text.includes("romantic") || text.includes("love") || text.includes("رومانسي") || text.includes("مشاعر") || text.includes("شيرين") || text.includes("إليسا") || text.includes("تامر حسني") || text.includes("كفوري")) {
    return "romantic";
  }
  if (text.includes("khaleeji") || text.includes("خليجي") || text.includes("عراقي") || text.includes("محمد عبده") || text.includes("المهندس") || text.includes("الساهر") || text.includes("راشد")) {
    return "khaleeji";
  }
  if (text.includes("calm") || text.includes("chill") || text.includes("lofi") || text.includes("piano") || text.includes("ambient") || text.includes("هادئ") || text.includes("استرخاء") || text.includes("عود") || text.includes("قانون")) {
    return "calm";
  }
  if (text.includes("world") || text.includes("latin") || text.includes("afro") || text.includes("عالمية") || text.includes("لاتيني") || text.includes("flamenco")) {
    return "world";
  }
  return "pop";
}

export function detectLanguage(text: string): "arabic" | "international" {
  const arabicRegex = /[\u0600-\u06FF\u0750-\u077F]/;
  return arabicRegex.test(text) ? "arabic" : "international";
}

// Fetch tracks from database with filter options
export async function getTracks(options?: {
  genreCategory?: GenreCategory;
  language?: MusicLanguage;
  limit?: number;
  offset?: number;
  featuredOnly?: boolean;
  trendingOnly?: boolean;
}): Promise<Track[]> {
  triggerBackgroundSeed();
  try {
    let query = db.select().from(cachedTracks);
    const conditions = [];

    if (options?.genreCategory && options.genreCategory !== "all") {
      conditions.push(eq(cachedTracks.genreCategory, options.genreCategory));
    }
    if (options?.language && options.language !== "all") {
      conditions.push(eq(cachedTracks.language, options.language));
    }
    if (options?.featuredOnly) {
      conditions.push(eq(cachedTracks.isFeatured, true));
    }
    if (options?.trendingOnly) {
      conditions.push(eq(cachedTracks.isTrending, true));
    }

    const rows = conditions.length > 0
      ? await query.where(and(...conditions)).limit(options?.limit || 120)
      : await query.limit(options?.limit || 120);

    if (rows.length > 0) {
      return rows.map(rowToTrack);
    }
  } catch (err) {
    console.error("Error reading tracks from DB:", err);
  }

  // Fallback to initial seeds filtered
  let filtered = [...INITIAL_FEATURED_TRACKS];
  if (options?.genreCategory && options.genreCategory !== "all") {
    filtered = filtered.filter((t) => t.genreCategory === options.genreCategory);
  }
  if (options?.language && options.language !== "all") {
    filtered = filtered.filter((t) => t.language === options.language);
  }
  if (options?.featuredOnly) {
    filtered = filtered.filter((t) => t.isFeatured);
  }
  if (options?.trendingOnly) {
    filtered = filtered.filter((t) => t.isTrending);
  }
  return filtered.slice(0, options?.limit || 120);
}

// Fetch all popular artists
export async function getArtists(options?: {
  genreCategory?: GenreCategory;
  language?: MusicLanguage;
  limit?: number;
}): Promise<Artist[]> {
  triggerBackgroundSeed();
  try {
    let query = db.select().from(artists);
    const conditions = [];

    if (options?.genreCategory && options.genreCategory !== "all") {
      conditions.push(eq(artists.genreCategory, options.genreCategory));
    }
    if (options?.language && options.language !== "all") {
      conditions.push(eq(artists.language, options.language));
    }

    const rows = conditions.length > 0
      ? await query.where(and(...conditions)).limit(options?.limit || 150)
      : await query.limit(options?.limit || 150);

    if (rows.length > 0) {
      return rows.map((r) => ({
        id: r.id,
        name: r.name,
        nameAr: r.nameAr,
        imageUrl: r.imageUrl,
        bio: r.bio || "",
        genre: r.genre || "موسيقى",
        genreCategory: (r.genreCategory as GenreCategory) || "pop",
        language: (r.language as "arabic" | "international") || "arabic",
        monthlyListeners: r.monthlyListeners || "1M+",
        isPopular: !!r.isPopular,
      }));
    }
  } catch (err) {
    console.error("Error getting artists from DB:", err);
  }

  let filtered = [...INITIAL_ARTISTS];
  if (options?.genreCategory && options.genreCategory !== "all") {
    filtered = filtered.filter((a) => a.genreCategory === options.genreCategory);
  }
  if (options?.language && options.language !== "all") {
    filtered = filtered.filter((a) => a.language === options.language);
  }
  return filtered.slice(0, options?.limit || 30);
}

// Fetch single artist by ID or Name with their top tracks
export async function getArtistDetails(artistIdOrName: string): Promise<{ artist: Artist | null; tracks: Track[]; albums: Album[] }> {
  try {
    const decoded = decodeURIComponent(artistIdOrName);
    const artistRows = await db
      .select()
      .from(artists)
      .where(or(eq(artists.id, decoded), ilike(artists.name, `%${decoded}%`), ilike(artists.nameAr, `%${decoded}%`)))
      .limit(1);

    let artist: Artist | null = null;
    if (artistRows.length > 0) {
      const r = artistRows[0];
      artist = {
        id: r.id,
        name: r.name,
        nameAr: r.nameAr,
        imageUrl: r.imageUrl,
        bio: r.bio || "",
        genre: r.genre || "موسيقى",
        genreCategory: (r.genreCategory as GenreCategory) || "pop",
        language: (r.language as "arabic" | "international") || "arabic",
        monthlyListeners: r.monthlyListeners || "2M+",
        isPopular: !!r.isPopular,
      };
    }

    const queryTerm = artist ? artist.name : decoded;
    
    // Check DB tracks
    const trackRows = await db
      .select()
      .from(cachedTracks)
      .where(or(ilike(cachedTracks.artistName, `%${queryTerm}%`), ilike(cachedTracks.artistName, `%${artist?.nameAr || ""}%`)))
      .limit(100);

    let tracks = trackRows.map(rowToTrack);

    // If tracks are few, fetch live from iTunes
    if (tracks.length < 15) {
      const itunesTracks = await searchItunes(queryTerm, 35);
      if (itunesTracks.length > 0) {
        tracks = [...tracks, ...itunesTracks.filter(it => !tracks.some(t => t.trackId === it.trackId))];
        if (!artist && itunesTracks[0]) {
          artist = {
            id: `artist_${encodeURIComponent(queryTerm)}`,
            name: itunesTracks[0].artistName,
            imageUrl: itunesTracks[0].artworkUrl,
            bio: `أفضل أغاني وأعمال الفنان ${itunesTracks[0].artistName}`,
            genre: itunesTracks[0].genre,
            genreCategory: itunesTracks[0].genreCategory,
            language: itunesTracks[0].language,
            monthlyListeners: "1.5M+",
          };
        }
      }
    }

    const albumRows = await db
      .select()
      .from(albums)
      .where(or(ilike(albums.artistName, `%${queryTerm}%`), ilike(albums.artistName, `%${artist?.nameAr || ""}%`)))
      .limit(12);

    const albumsList: Album[] = albumRows.map((a) => ({
      id: a.id,
      title: a.title,
      artistName: a.artistName,
      artistId: a.artistId || undefined,
      coverUrl: a.coverUrl,
      releaseYear: a.releaseYear || "2024",
      genre: a.genre || "موسيقى",
      genreCategory: (a.genreCategory as GenreCategory) || "pop",
      language: (a.language as "arabic" | "international") || "arabic",
      totalTracks: a.totalTracks || 10,
    }));

    return { artist, tracks, albums: albumsList };
  } catch (err) {
    console.error("Error getting artist details:", err);
    return { artist: null, tracks: [], albums: [] };
  }
}

// Fetch albums
export async function getAlbums(options?: {
  genreCategory?: GenreCategory;
  language?: MusicLanguage;
  limit?: number;
}): Promise<Album[]> {
  try {
    let query = db.select().from(albums);
    const conditions = [];

    if (options?.genreCategory && options.genreCategory !== "all") {
      conditions.push(eq(albums.genreCategory, options.genreCategory));
    }
    if (options?.language && options.language !== "all") {
      conditions.push(eq(albums.language, options.language));
    }

    const rows = conditions.length > 0
      ? await query.where(and(...conditions)).limit(options?.limit || 250)
      : await query.limit(options?.limit || 250);

    return rows.map((a) => ({
      id: a.id,
      title: a.title,
      artistName: a.artistName,
      artistId: a.artistId || undefined,
      coverUrl: a.coverUrl,
      releaseYear: a.releaseYear || "2024",
      genre: a.genre || "موسيقى",
      genreCategory: (a.genreCategory as GenreCategory) || "pop",
      language: (a.language as "arabic" | "international") || "arabic",
      totalTracks: a.totalTracks || 10,
    }));
  } catch (err) {
    console.error("Error getting albums:", err);
    return [];
  }
}

// Search iTunes API Live
export async function searchItunes(term: string, limit: number = 20): Promise<Track[]> {
  try {
    const cleanTerm = term.trim();
    if (!cleanTerm) return [];

    const url = `https://itunes.apple.com/search?term=${encodeURIComponent(cleanTerm)}&entity=song&limit=${limit}`;
    const res = await fetch(url, { headers: { "User-Agent": "NaghamMusicApp/1.0" }, next: { revalidate: 3600 } });
    if (!res.ok) return [];

    const data = await res.json();
    const results = data.results || [];

    const tracks: Track[] = [];

    for (const item of results) {
      if (!item.previewUrl) continue;

      const trackArtwork = (item.artworkUrl100 || "").replace("100x100bb.jpg", "600x600bb.jpg");
      const fullDurSec = matchFullSongSource(item.trackName || "", item.artistName || "")?.fullDuration || 
        (item.trackTimeMillis ? Math.round(item.trackTimeMillis / 1000) : 240);
      const genreCat = detectGenreCategory(item.primaryGenreName, item.trackName, item.artistName);
      const lang = detectLanguage(`${item.trackName} ${item.artistName}`);

      // Check if known full YouTube stream exists
      const match = matchFullSongSource(item.trackName || "", item.artistName || "");
      const youtubeId = match?.youtubeId || null;

      const trackObj: Track = {
        id: `itunes_${item.trackId}`,
        trackId: `itunes_${item.trackId}`,
        title: item.trackName || "أغنية",
        artistName: item.artistName || "فنان",
        albumName: item.collectionName || "ألبوم",
        artworkUrl: trackArtwork,
        previewUrl: item.previewUrl,
        youtubeVideoId: youtubeId,
        durationSeconds: fullDurSec,
        fullDurationSeconds: fullDurSec,
        playbackType: "youtube_official",
        isFullPlayable: true,
        genre: item.primaryGenreName || "عام",
        genreCategory: genreCat,
        language: lang,
        releaseDate: item.releaseDate || "",
        externalAppleMusicUrl: item.trackViewUrl,
        externalSpotifyUrl: `https://open.spotify.com/search/${encodeURIComponent(`${item.artistName} ${item.trackName}`)}`,
        externalYoutubeUrl: youtubeId ? `https://www.youtube.com/watch?v=${youtubeId}` : `https://www.youtube.com/results?search_query=${encodeURIComponent(
          `${item.artistName} ${item.trackName}`
        )}`,
        externalAnghamiUrl: `https://play.anghami.com/search/${encodeURIComponent(`${item.artistName} ${item.trackName}`)}`,
        externalDeezerUrl: `https://www.deezer.com/search/${encodeURIComponent(`${item.artistName} ${item.trackName}`)}`,
        source: "itunes",
      };

      tracks.push(trackObj);

      // Cache to DB asynchronously without blocking
      db.insert(cachedTracks)
        .values({
          trackId: trackObj.trackId,
          title: trackObj.title,
          artistName: trackObj.artistName,
          albumName: trackObj.albumName,
          artworkUrl: trackObj.artworkUrl,
          previewUrl: trackObj.previewUrl,
          youtubeVideoId: trackObj.youtubeVideoId,
          isFullPlayable: trackObj.isFullPlayable,
          fullDurationSeconds: trackObj.fullDurationSeconds,
          playbackType: trackObj.playbackType,
          externalAppleMusicUrl: trackObj.externalAppleMusicUrl,
          externalSpotifyUrl: trackObj.externalSpotifyUrl,
          externalYoutubeUrl: trackObj.externalYoutubeUrl,
          externalAnghamiUrl: trackObj.externalAnghamiUrl,
          externalDeezerUrl: trackObj.externalDeezerUrl,
          durationSeconds: trackObj.durationSeconds,
          genre: trackObj.genre,
          genreCategory: trackObj.genreCategory,
          language: trackObj.language,
          releaseDate: trackObj.releaseDate,
        })
        .onConflictDoNothing()
        .catch(() => {});
    }

    return tracks;
  } catch (err) {
    console.error("iTunes search error:", err);
    return [];
  }
}

// Multi-Source Live Search (DB + iTunes)
export async function performGlobalSearch(query: string): Promise<SearchResult> {
  const clean = query.trim();
  if (!clean) {
    return { tracks: [], artists: [], albums: [], playlists: [], totalResults: 0 };
  }

  // 1. Search local DB
  const [dbTrackRows, dbArtistRows, dbAlbumRows, dbPlaylistRows] = await Promise.all([
    db
      .select()
      .from(cachedTracks)
      .where(or(ilike(cachedTracks.title, `%${clean}%`), ilike(cachedTracks.artistName, `%${clean}%`)))
      .limit(15),
    db
      .select()
      .from(artists)
      .where(or(ilike(artists.name, `%${clean}%`), ilike(artists.nameAr, `%${clean}%`)))
      .limit(8),
    db
      .select()
      .from(albums)
      .where(or(ilike(albums.title, `%${clean}%`), ilike(albums.artistName, `%${clean}%`)))
      .limit(6),
    db
      .select()
      .from(playlists)
      .where(or(ilike(playlists.name, `%${clean}%`), ilike(playlists.description, `%${clean}%`)))
      .limit(6),
  ]);

  let tracks = dbTrackRows.map(rowToTrack);

  // 2. Query iTunes live
  const itunesResults = await searchItunes(clean, 20);

  // Merge & deduplicate tracks by trackId or Title+Artist
  const seenIds = new Set<string>();
  const mergedTracks: Track[] = [];

  for (const t of [...tracks, ...itunesResults]) {
    const key = `${t.title.toLowerCase()}_${t.artistName.toLowerCase()}`;
    if (!seenIds.has(t.trackId) && !seenIds.has(key)) {
      seenIds.add(t.trackId);
      seenIds.add(key);
      mergedTracks.push(t);
    }
  }

  const artistsResult: Artist[] = dbArtistRows.map((r) => ({
    id: r.id,
    name: r.name,
    nameAr: r.nameAr,
    imageUrl: r.imageUrl,
    bio: r.bio || "",
    genre: r.genre || "موسيقى",
    genreCategory: (r.genreCategory as GenreCategory) || "pop",
    language: (r.language as "arabic" | "international") || "arabic",
    monthlyListeners: r.monthlyListeners || "1M+",
  }));

  const albumsResult: Album[] = dbAlbumRows.map((a) => ({
    id: a.id,
    title: a.title,
    artistName: a.artistName,
    artistId: a.artistId || undefined,
    coverUrl: a.coverUrl,
    releaseYear: a.releaseYear || "2024",
    genre: a.genre || "موسيقى",
    genreCategory: (a.genreCategory as GenreCategory) || "pop",
    language: (a.language as "arabic" | "international") || "arabic",
    totalTracks: a.totalTracks || 10,
  }));

  const playlistsResult: Playlist[] = dbPlaylistRows.map((p) => ({
    id: p.id,
    name: p.name,
    description: p.description || "",
    coverUrl: p.coverUrl || "",
    isSystem: !!p.isSystem,
    genreCategory: (p.genreCategory as GenreCategory) || "pop",
  }));

  return {
    tracks: mergedTracks,
    artists: artistsResult,
    albums: albumsResult,
    playlists: playlistsResult,
    totalResults: mergedTracks.length + artistsResult.length + albumsResult.length + playlistsResult.length,
  };
}

// Fetch Playlists
export async function getPlaylists(): Promise<Playlist[]> {
  try {
    const rows = await db.select().from(playlists).orderBy(desc(playlists.isSystem), desc(playlists.createdAt));
    return rows.map((p) => ({
      id: p.id,
      name: p.name,
      description: p.description || "",
      coverUrl: p.coverUrl || "",
      isSystem: !!p.isSystem,
      genreCategory: (p.genreCategory as GenreCategory) || "pop",
      createdAt: p.createdAt ? p.createdAt.toISOString() : undefined,
    }));
  } catch (err) {
    console.error("Error getting playlists:", err);
    return [];
  }
}

// Fetch single playlist with its items
export async function getPlaylistDetails(playlistId: string): Promise<{ playlist: Playlist | null; tracks: Track[] }> {
  try {
    const playlistRows = await db.select().from(playlists).where(eq(playlists.id, playlistId)).limit(1);
    if (playlistRows.length === 0) {
      return { playlist: null, tracks: [] };
    }

    const p = playlistRows[0];
    const items = await db
      .select()
      .from(playlistItems)
      .where(eq(playlistItems.playlistId, playlistId))
      .orderBy(playlistItems.position);

    let tracks: Track[] = items.map((item) => ({
      id: item.trackId,
      trackId: item.trackId,
      title: item.title,
      artistName: item.artistName,
      albumName: item.albumName || "",
      artworkUrl: item.artworkUrl || "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600",
      previewUrl: item.previewUrl,
      youtubeVideoId: item.youtubeVideoId || null,
      fullStreamUrl: item.fullStreamUrl || null,
      isFullPlayable: !!item.isFullPlayable,
      fullDurationSeconds: item.fullDurationSeconds || null,
      playbackType: (item.playbackType as TrackPlaybackType) || "preview_only",
      durationSeconds: item.durationSeconds || 30,
      genre: "موسيقى",
      genreCategory: "pop",
      language: "arabic",
    }));

    // If system playlist has no items yet, populate with matching genre tracks
    if (tracks.length === 0 && p.genreCategory) {
      tracks = await getTracks({ genreCategory: p.genreCategory as GenreCategory, limit: 12 });
    }

    const playlist: Playlist = {
      id: p.id,
      name: p.name,
      description: p.description || "",
      coverUrl: p.coverUrl || (tracks[0]?.artworkUrl ?? ""),
      isSystem: !!p.isSystem,
      genreCategory: (p.genreCategory as GenreCategory) || "pop",
      trackCount: tracks.length,
      tracks: tracks,
    };

    return { playlist, tracks };
  } catch (err) {
    console.error("Error getting playlist details:", err);
    return { playlist: null, tracks: [] };
  }
}

import { NextResponse } from "next/server";
import fs from "fs";
import path from "path";

export async function GET() {
  try {
    const filePath = path.join(process.cwd(), "public", "downloads", "Nagham-Music-v2.0.apk");

    if (!fs.existsSync(filePath)) {
      const { execSync } = await import("child_process");
      execSync("python3 scripts/build_android_apk.py");
    }

    const fileBuffer = fs.readFileSync(filePath);

    return new NextResponse(fileBuffer, {
      status: 200,
      headers: {
        "Content-Type": "application/vnd.android.package-archive",
        "Content-Disposition": 'attachment; filename="Nagham-Music-v2.0.apk"',
        "Content-Length": fileBuffer.length.toString(),
        "Cache-Control": "public, max-age=31536000, immutable",
      },
    });
  } catch (error: any) {
    console.error("GET /api/download-apk error:", error);
    return NextResponse.json({ success: false, error: "تعذر تحميل ملف APK" }, { status: 500 });
  }
}

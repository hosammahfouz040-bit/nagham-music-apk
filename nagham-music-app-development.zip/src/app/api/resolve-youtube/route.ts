import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { cachedTracks } from "@/db/schema";
import { eq } from "drizzle-orm";
import { matchFullSongSource } from "@/lib/music-service";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const title = searchParams.get("title") || "";
    const artist = searchParams.get("artist") || "";
    const trackId = searchParams.get("trackId") || "";

    if (!title && !artist && !trackId) {
      return NextResponse.json({ success: false, error: "Missing parameters" }, { status: 400 });
    }

    // 1. Check if track already has video ID in DB
    if (trackId) {
      const existing = await db
        .select()
        .from(cachedTracks)
        .where(eq(cachedTracks.trackId, trackId))
        .limit(1);

      if (existing.length > 0 && existing[0].youtubeVideoId) {
        return NextResponse.json({
          success: true,
          youtubeVideoId: existing[0].youtubeVideoId,
          fullDurationSeconds: existing[0].fullDurationSeconds || 240,
          source: "database_cache",
        });
      }
    }

    // 2. Check local catalog mapping
    const match = matchFullSongSource(title, artist);
    if (match?.youtubeId) {
      if (trackId) {
        await db
          .update(cachedTracks)
          .set({
            youtubeVideoId: match.youtubeId,
            isFullPlayable: true,
            fullDurationSeconds: match.fullDuration || 240,
            playbackType: "youtube_official",
          })
          .where(eq(cachedTracks.trackId, trackId))
          .catch(() => {});
      }
      return NextResponse.json({
        success: true,
        youtubeVideoId: match.youtubeId,
        fullDurationSeconds: match.fullDuration || 240,
        source: "known_catalog",
      });
    }

    // 3. Dynamic Real-time Official YouTube Resolution
    const searchQuery = `${artist} ${title} official audio`;
    const searchUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(searchQuery)}`;

    const res = await fetch(searchUrl, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept-Language": "ar,en;q=0.9",
      },
      next: { revalidate: 86400 },
    });

    if (res.ok) {
      const html = await res.text();
      const videoIdMatch = html.match(/"videoId":"([a-zA-Z0-9_-]{11})"/);

      if (videoIdMatch && videoIdMatch[1]) {
        const resolvedId = videoIdMatch[1];
        const estimatedDur = 240;

        if (trackId) {
          await db
            .update(cachedTracks)
            .set({
              youtubeVideoId: resolvedId,
              isFullPlayable: true,
              fullDurationSeconds: estimatedDur,
              playbackType: "youtube_official",
            })
            .where(eq(cachedTracks.trackId, trackId))
            .catch(() => {});
        }

        return NextResponse.json({
          success: true,
          youtubeVideoId: resolvedId,
          fullDurationSeconds: estimatedDur,
          source: "realtime_resolver",
        });
      }
    }

    return NextResponse.json({
      success: false,
      error: "Could not resolve video ID",
    });
  } catch (error: any) {
    console.error("GET /api/resolve-youtube error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

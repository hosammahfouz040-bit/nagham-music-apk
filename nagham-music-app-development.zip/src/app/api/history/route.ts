import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { listeningHistory, cachedTracks } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";

export async function GET() {
  try {
    const rows = await db.select().from(listeningHistory).orderBy(desc(listeningHistory.playedAt)).limit(50);
    return NextResponse.json({
      success: true,
      count: rows.length,
      data: rows.map((r) => ({
        id: r.id,
        trackId: r.trackId,
        title: r.title,
        artistName: r.artistName,
        albumName: r.albumName || "",
        artworkUrl: r.artworkUrl || "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600",
        previewUrl: r.previewUrl,
        durationSeconds: r.durationSeconds || 30,
        genre: r.genre || "موسيقى",
        playedAt: r.playedAt.toISOString(),
      })),
    });
  } catch (error: any) {
    console.error("GET /api/history error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { trackId, title, artistName, albumName, artworkUrl, previewUrl, durationSeconds, genre } = body;

    if (!trackId || !title || !previewUrl) {
      return NextResponse.json({ success: false, error: "بيانات ناقصة" }, { status: 400 });
    }

    // Insert history
    await db.insert(listeningHistory).values({
      trackId,
      title,
      artistName: artistName || "فنان",
      albumName: albumName || "",
      artworkUrl: artworkUrl || "",
      previewUrl,
      durationSeconds: durationSeconds || 30,
      genre: genre || "موسيقى",
    });

    // Increment play count in cachedTracks if exists
    try {
      await db
        .update(cachedTracks)
        .set({ playCount: sql`${cachedTracks.playCount} + 1` })
        .where(eq(cachedTracks.trackId, trackId));
    } catch {
      // Non-critical
    }

    return NextResponse.json({ success: true, message: "تم تسجيل الاستماع" });
  } catch (error: any) {
    console.error("POST /api/history error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function DELETE() {
  try {
    await db.delete(listeningHistory);
    return NextResponse.json({ success: true, message: "تم مسح سجل الاستماع" });
  } catch (error: any) {
    console.error("DELETE /api/history error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

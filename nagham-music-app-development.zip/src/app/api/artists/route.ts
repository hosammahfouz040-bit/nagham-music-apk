import { NextRequest, NextResponse } from "next/server";
import { getArtists } from "@/lib/music-service";
import { GenreCategory, MusicLanguage } from "@/lib/types";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const genre = (searchParams.get("genre") as GenreCategory) || undefined;
    const language = (searchParams.get("language") as MusicLanguage) || undefined;
    const limit = searchParams.get("limit") ? parseInt(searchParams.get("limit")!, 10) : 30;

    const artistsList = await getArtists({
      genreCategory: genre,
      language: language,
      limit: Math.min(limit, 250),
    });

    return NextResponse.json({
      success: true,
      count: artistsList.length,
      data: artistsList,
    });
  } catch (error: any) {
    console.error("GET /api/artists error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

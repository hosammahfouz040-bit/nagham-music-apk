import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { playlistItems } from "@/db/schema";
import { eq, and } from "drizzle-orm";

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: playlistId } = await params;
    const body = await req.json();
    const {
      trackId,
      title,
      artistName,
      albumName,
      artworkUrl,
      previewUrl,
      youtubeVideoId,
      fullStreamUrl,
      isFullPlayable,
      fullDurationSeconds,
      playbackType,
      durationSeconds,
    } = body;

    if (!trackId || !title || !previewUrl) {
      return NextResponse.json({ success: false, error: "بيانات الأغنية غير مكتملة" }, { status: 400 });
    }

    // Check if already in playlist
    const existing = await db
      .select()
      .from(playlistItems)
      .where(and(eq(playlistItems.playlistId, playlistId), eq(playlistItems.trackId, trackId)))
      .limit(1);

    if (existing.length > 0) {
      return NextResponse.json({ success: true, message: "الأغنية موجودة بالفعل في القائمة" });
    }

    await db.insert(playlistItems).values({
      playlistId,
      trackId,
      title,
      artistName: artistName || "فنان غير معروف",
      albumName: albumName || "",
      artworkUrl: artworkUrl || "",
      previewUrl,
      youtubeVideoId: youtubeVideoId || null,
      fullStreamUrl: fullStreamUrl || null,
      isFullPlayable: !!isFullPlayable,
      fullDurationSeconds: fullDurationSeconds || null,
      playbackType: playbackType || "preview_only",
      durationSeconds: durationSeconds || 30,
    });

    return NextResponse.json({ success: true, message: "تمت إضافة الأغنية إلى قائمة التشغيل" });
  } catch (error: any) {
    console.error("POST /api/playlists/[id]/items error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: playlistId } = await params;
    const { searchParams } = new URL(req.url);
    const trackId = searchParams.get("trackId");

    if (!trackId) {
      return NextResponse.json({ success: false, error: "معرّف الأغنية مطلوب" }, { status: 400 });
    }

    await db
      .delete(playlistItems)
      .where(and(eq(playlistItems.playlistId, playlistId), eq(playlistItems.trackId, trackId)));

    return NextResponse.json({ success: true, message: "تم حذف الأغنية من قائمة التشغيل" });
  } catch (error: any) {
    console.error("DELETE /api/playlists/[id]/items error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

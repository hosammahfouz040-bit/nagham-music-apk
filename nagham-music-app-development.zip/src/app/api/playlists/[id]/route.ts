import { NextRequest, NextResponse } from "next/server";
import { getPlaylistDetails } from "@/lib/music-service";
import { db } from "@/db";
import { playlists, playlistItems } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const result = await getPlaylistDetails(id);

    if (!result.playlist) {
      return NextResponse.json({ success: false, error: "قائمة التشغيل غير موجودة" }, { status: 404 });
    }

    return NextResponse.json({ success: true, data: result });
  } catch (error: any) {
    console.error("GET /api/playlists/[id] error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    // Don't delete system playlists
    const target = await db.select().from(playlists).where(eq(playlists.id, id)).limit(1);
    if (target.length > 0 && target[0].isSystem) {
      return NextResponse.json({ success: false, error: "لا يمكن حذف قوائم التشغيل الرسمية" }, { status: 403 });
    }

    await db.delete(playlistItems).where(eq(playlistItems.playlistId, id));
    await db.delete(playlists).where(eq(playlists.id, id));

    return NextResponse.json({ success: true, message: "تم حذف قائمة التشغيل بنجاح" });
  } catch (error: any) {
    console.error("DELETE /api/playlists/[id] error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

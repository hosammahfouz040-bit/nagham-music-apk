import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { playlists, playlistItems } from "@/db/schema";
import { getPlaylists } from "@/lib/music-service";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const list = await getPlaylists();
    return NextResponse.json({ success: true, count: list.length, data: list });
  } catch (error: any) {
    console.error("GET /api/playlists error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, description, coverUrl, genreCategory } = body;

    if (!name || typeof name !== "string") {
      return NextResponse.json({ success: false, error: "اسم قائمة التشغيل مطلوب" }, { status: 400 });
    }

    const playlistId = `custom_pl_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;

    await db.insert(playlists).values({
      id: playlistId,
      name: name.trim(),
      description: description || "",
      coverUrl: coverUrl || "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600",
      isSystem: false,
      genreCategory: genreCategory || "pop",
    });

    return NextResponse.json({
      success: true,
      message: "تم إنشاء قائمة التشغيل بنجاح",
      data: { id: playlistId, name, description, coverUrl },
    });
  } catch (error: any) {
    console.error("POST /api/playlists error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

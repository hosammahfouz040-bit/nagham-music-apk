import { NextRequest, NextResponse } from "next/server";
import { getTracks } from "@/lib/music-service";
import { GenreCategory, MusicLanguage } from "@/lib/types";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const genre = (searchParams.get("genre") as GenreCategory) || undefined;
    const language = (searchParams.get("language") as MusicLanguage) || undefined;
    const limit = searchParams.get("limit") ? parseInt(searchParams.get("limit")!, 10) : 30;
    const featured = searchParams.get("featured") === "true";
    const trending = searchParams.get("trending") === "true";

    const tracks = await getTracks({
      genreCategory: genre,
      language: language,
      limit: Math.min(limit, 500),
      featuredOnly: featured,
      trendingOnly: trending,
    });

    return NextResponse.json({
      success: true,
      count: tracks.length,
      data: tracks,
    });
  } catch (error: any) {
    console.error("GET /api/tracks error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

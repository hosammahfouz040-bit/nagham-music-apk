import { NextResponse } from "next/server";
import { db } from "@/db";
import { cachedTracks, artists, albums, playlists } from "@/db/schema";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const [tracksCountRes, artistsCountRes, albumsCountRes, playlistsCountRes] = await Promise.all([
      db.select({ count: sql<number>`count(*)` }).from(cachedTracks),
      db.select({ count: sql<number>`count(*)` }).from(artists),
      db.select({ count: sql<number>`count(*)` }).from(albums),
      db.select({ count: sql<number>`count(*)` }).from(playlists),
    ]);

    const totalTracks = Number(tracksCountRes[0]?.count || 0);
    const totalArtists = Number(artistsCountRes[0]?.count || 0);
    const totalAlbums = Number(albumsCountRes[0]?.count || 0);
    const totalPlaylists = Number(playlistsCountRes[0]?.count || 0);

    return NextResponse.json({
      success: true,
      data: {
        totalTracks,
        totalArtists,
        totalAlbums,
        totalPlaylists,
        formattedTracks: totalTracks.toLocaleString("ar-EG"),
      },
    });
  } catch (error: any) {
    console.error("GET /api/stats error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

"use client";

import React, { useState, useEffect, use } from "react";
import Link from "next/link";
import { Artist, Track, Album } from "@/lib/types";
import { usePlayer } from "@/context/PlayerContext";
import { TrackCard } from "@/components/TrackCard";
import { AlbumCard } from "@/components/AlbumCard";
import { PlaylistModal } from "@/components/PlaylistModal";
import {
  Play,
  Shuffle,
  ChevronLeft,
  Mic2,
  Disc3,
  CheckCircle2,
  Users,
  Sparkles,
} from "lucide-react";

export default function ArtistDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const resolvedParams = use(params);
  const artistId = resolvedParams.id;
  const { playTrack } = usePlayer();

  const [artist, setArtist] = useState<Artist | null>(null);
  const [tracks, setTracks] = useState<Track[]>([]);
  const [albums, setAlbums] = useState<Album[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTrackForPlaylist, setSelectedTrackForPlaylist] = useState<Track | null>(null);
  const [isPlaylistModalOpen, setIsPlaylistModalOpen] = useState(false);

  useEffect(() => {
    fetchArtistData();
  }, [artistId]);

  const fetchArtistData = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/artists/${encodeURIComponent(artistId)}`);
      const data = await res.json();
      if (data.success && data.data) {
        setArtist(data.data.artist);
        setTracks(data.data.tracks || []);
        setAlbums(data.data.albums || []);
      }
    } catch (err) {
      console.error("Error loading artist details:", err);
    } finally {
      setLoading(false);
    }
  };

  const handlePlayAll = (shuffle: boolean = false) => {
    if (tracks.length === 0) return;
    const queueToPlay = shuffle ? [...tracks].sort(() => Math.random() - 0.5) : tracks;
    playTrack(queueToPlay[0], queueToPlay);
  };

  const displayName = artist?.nameAr || artist?.name || decodeURIComponent(artistId);

  return (
    <div className="flex flex-col gap-8">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-xs text-zinc-400 font-medium">
        <Link href="/" className="hover:text-emerald-400 transition">الرئيسية</Link>
        <ChevronLeft className="w-3.5 h-3.5 rtl:rotate-180 text-zinc-600" />
        <Link href="/artists" className="hover:text-emerald-400 transition">المطربون</Link>
        <ChevronLeft className="w-3.5 h-3.5 rtl:rotate-180 text-zinc-600" />
        <span className="text-white font-bold">{displayName}</span>
      </div>

      {/* Artist Profile Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#12121a] via-[#161622] to-emerald-950/40 border border-white/[0.08] p-6 sm:p-8 lg:p-10 shadow-2xl">
        <div className="relative z-10 flex flex-col sm:flex-row items-center gap-6 sm:gap-8">
          {/* Avatar */}
          <div className="relative w-36 h-36 sm:w-48 sm:h-48 rounded-full overflow-hidden shrink-0 border-4 border-white/[0.1] shadow-2xl shadow-black/80">
            {artist?.imageUrl ? (
              <img src={artist.imageUrl} alt={displayName} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full bg-zinc-900 flex items-center justify-center">
                <Mic2 className="w-16 h-16 text-zinc-500" />
              </div>
            )}
          </div>

          {/* Info */}
          <div className="text-right flex-1">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 px-3.5 py-1 rounded-full font-bold shadow-sm">
                فنان موثق
              </span>
              <span className="text-xs bg-white/[0.06] text-zinc-300 px-3 py-1 rounded-full border border-white/[0.06] font-medium">
                {artist?.genre || "موسيقى"}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <h1 className="text-2xl sm:text-4xl lg:text-5xl font-black text-white">{displayName}</h1>
              <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
            </div>

            {artist?.nameAr && artist.name !== artist.nameAr && (
              <p className="text-sm text-zinc-400 mt-1 font-medium">{artist.name}</p>
            )}

            <p className="text-xs sm:text-sm text-zinc-300 max-w-xl leading-relaxed mt-3 font-medium">
              {artist?.bio || `استمع إلى أفضل أغاني وأعمال الفنان ${displayName} كاملة عبر منصة نغم.`}
            </p>

            <div className="flex items-center gap-4 text-xs text-zinc-400 my-4 font-semibold">
              <span className="flex items-center gap-1.5">
                <Users className="w-4 h-4 text-emerald-400" />
                {artist?.monthlyListeners || "1M+"} مستمع شهري
              </span>
              <span>•</span>
              <span className="text-emerald-400">{tracks.length} أغنية كاملة</span>
            </div>

            {/* Play all buttons */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => handlePlayAll(false)}
                disabled={tracks.length === 0}
                className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-zinc-950 font-black text-sm flex items-center gap-2.5 shadow-xl shadow-emerald-500/25 hover:scale-105 active:scale-95 transition disabled:opacity-50"
              >
                <Play className="w-5 h-5 fill-zinc-950" />
                <span>تشغيل الكل ({tracks.length})</span>
              </button>

              <button
                onClick={() => handlePlayAll(true)}
                disabled={tracks.length === 0}
                className="px-5 py-3.5 rounded-2xl bg-[#1a1a26] hover:bg-[#222234] text-zinc-200 text-xs font-bold flex items-center gap-2 border border-white/[0.08] transition disabled:opacity-50"
              >
                <Shuffle className="w-4 h-4 text-emerald-400" />
                <span>تشغيل عشوائي</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Top Tracks List */}
      <section className="flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-emerald-400" />
            <h2 className="text-lg font-bold text-white">الأغاني الأكثر استماعاً ({tracks.length})</h2>
          </div>
          <span className="text-xs text-zinc-400 font-medium">أغاني كاملة</span>
        </div>

        {loading ? (
          <div className="p-12 text-center text-zinc-500 text-sm">جاري تحميل الأغاني...</div>
        ) : tracks.length === 0 ? (
          <div className="p-12 text-center bg-[#121218]/50 rounded-3xl border border-white/[0.08] text-zinc-400">
            لا توجد أغاني مسجلة لهذا الفنان حالياً.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5">
            {tracks.map((track, idx) => (
              <TrackCard
                key={track.trackId}
                track={track}
                trackList={tracks}
                viewMode="list"
                index={idx}
                onAddToPlaylist={(t) => {
                  setSelectedTrackForPlaylist(t);
                  setIsPlaylistModalOpen(true);
                }}
              />
            ))}
          </div>
        )}
      </section>

      {/* Albums Section if available */}
      {albums.length > 0 && (
        <section className="flex flex-col gap-4">
          <div className="flex items-center gap-2">
            <Disc3 className="w-5 h-5 text-indigo-400" />
            <h2 className="text-lg font-bold text-white">الألبومات والإصدارات ({albums.length})</h2>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3.5">
            {albums.map((album) => (
              <AlbumCard key={album.id} album={album} />
            ))}
          </div>
        </section>
      )}

      {/* Playlist modal */}
      <PlaylistModal
        isOpen={isPlaylistModalOpen}
        onClose={() => setIsPlaylistModalOpen(false)}
        selectedTrack={selectedTrackForPlaylist}
      />
    </div>
  );
}

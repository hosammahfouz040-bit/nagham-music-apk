"use client";

import React, { useState, useEffect, use } from "react";
import Link from "next/link";
import { GENRES } from "@/lib/constants";
import { Track, Artist, GenreCategory } from "@/lib/types";
import { usePlayer } from "@/context/PlayerContext";
import { TrackCard } from "@/components/TrackCard";
import { ArtistCard } from "@/components/ArtistCard";
import { PlaylistModal } from "@/components/PlaylistModal";
import {
  Play,
  Shuffle,
  ChevronLeft,
  Layers,
  Sparkles,
  Mic2,
  Music,
} from "lucide-react";

export default function GenreDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const resolvedParams = use(params);
  const genreId = resolvedParams.id as GenreCategory;
  const { playTrack } = usePlayer();

  const genreInfo = GENRES.find((g) => g.id === genreId) || {
    id: genreId,
    title: genreId,
    titleEn: genreId,
    description: "قسم موسيقي مخصص في تطبيق نغم",
    icon: "Music",
    color: "#10B981",
    bgGradient: "from-emerald-950/80 via-zinc-900 to-black",
    language: "both" as const,
    featuredArtists: [],
  };

  const [tracks, setTracks] = useState<Track[]>([]);
  const [artists, setArtists] = useState<Artist[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTrackForPlaylist, setSelectedTrackForPlaylist] = useState<Track | null>(null);
  const [isPlaylistModalOpen, setIsPlaylistModalOpen] = useState(false);

  useEffect(() => {
    fetchGenreData();
  }, [genreId]);

  const fetchGenreData = async () => {
    setLoading(true);
    try {
      const [tracksRes, artistsRes] = await Promise.all([
        fetch(`/api/tracks?genre=${genreId}&limit=100`),
        fetch(`/api/artists?genre=${genreId}&limit=24`),
      ]);

      const [tracksData, artistsData] = await Promise.all([tracksRes.json(), artistsRes.json()]);

      if (tracksData.success && Array.isArray(tracksData.data)) {
        setTracks(tracksData.data);
      }
      if (artistsData.success && Array.isArray(artistsData.data)) {
        setArtists(artistsData.data);
      }
    } catch (err) {
      console.error("Error loading genre data:", err);
    } finally {
      setLoading(false);
    }
  };

  const handlePlayAll = (shuffle: boolean = false) => {
    if (tracks.length === 0) return;
    const queueToPlay = shuffle ? [...tracks].sort(() => Math.random() - 0.5) : tracks;
    playTrack(queueToPlay[0], queueToPlay);
  };

  return (
    <div className="flex flex-col gap-8">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-xs text-zinc-400 font-medium">
        <Link href="/" className="hover:text-emerald-400 transition">الرئيسية</Link>
        <ChevronLeft className="w-3.5 h-3.5 rtl:rotate-180 text-zinc-600" />
        <Link href="/genres" className="hover:text-emerald-400 transition">الأنواع والتصنيفات</Link>
        <ChevronLeft className="w-3.5 h-3.5 rtl:rotate-180 text-zinc-600" />
        <span className="text-white font-bold">{genreInfo.title}</span>
      </div>

      {/* Genre Header Banner */}
      <div
        className="relative overflow-hidden rounded-3xl p-6 sm:p-8 lg:p-10 border border-white/[0.08] shadow-2xl"
        style={{
          background: `linear-gradient(135deg, ${genreInfo.color}35 0%, #0d0d14 100%)`,
        }}
      >
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="text-right flex-1">
            <span
              className="text-xs font-bold uppercase tracking-wider px-3.5 py-1 rounded-full border mb-3 inline-block shadow-sm"
              style={{
                backgroundColor: `${genreInfo.color}25`,
                borderColor: `${genreInfo.color}45`,
                color: genreInfo.color,
              }}
            >
              {genreInfo.titleEn}
            </span>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white mb-3">{genreInfo.title}</h1>
            <p className="text-sm sm:text-base text-zinc-300 max-w-2xl leading-relaxed mb-6 font-medium">
              {genreInfo.description}
            </p>

            {/* Play all buttons */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => handlePlayAll(false)}
                disabled={tracks.length === 0}
                className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-zinc-950 font-black text-sm flex items-center gap-2.5 shadow-xl shadow-emerald-500/25 hover:scale-105 active:scale-95 transition disabled:opacity-50"
              >
                <Play className="w-5 h-5 fill-zinc-950" />
                <span>تشغيل الكل ({tracks.length})</span>
              </button>

              <button
                onClick={() => handlePlayAll(true)}
                disabled={tracks.length === 0}
                className="px-5 py-3.5 rounded-2xl bg-[#1a1a26] hover:bg-[#222234] text-zinc-200 text-xs font-bold flex items-center gap-2 border border-white/[0.08] transition disabled:opacity-50"
              >
                <Shuffle className="w-4 h-4 text-emerald-400" />
                <span>تشغيل عشوائي</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Prominent Artists in this Genre */}
      {artists.length > 0 && (
        <section className="flex flex-col gap-4">
          <div className="flex items-center gap-2">
            <Mic2 className="w-5 h-5 text-emerald-400" />
            <h2 className="text-lg font-bold text-white">فنانو ومطربو هذا القسم</h2>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3.5">
            {artists.map((artist) => (
              <ArtistCard key={artist.id} artist={artist} />
            ))}
          </div>
        </section>
      )}

      {/* Tracks in this Genre */}
      <section className="flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Music className="w-5 h-5 text-emerald-400" />
            <h2 className="text-lg font-bold text-white">أغاني قسم {genreInfo.title} ({tracks.length})</h2>
          </div>
          <span className="text-xs text-zinc-400 font-medium">{tracks.length} أغنية كاملة</span>
        </div>

        {loading ? (
          <div className="p-12 text-center text-zinc-500 text-sm">جاري تحميل الأغاني...</div>
        ) : tracks.length === 0 ? (
          <div className="p-12 text-center bg-[#121218]/50 rounded-3xl border border-white/[0.08]">
            <p className="text-sm text-zinc-400">لا توجد أغاني في هذا القسم حالياً، جرب البحث أو تحديث الصفحة.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5">
            {tracks.map((track, idx) => (
              <TrackCard
                key={track.trackId}
                track={track}
                trackList={tracks}
                viewMode="list"
                index={idx}
                onAddToPlaylist={(t) => {
                  setSelectedTrackForPlaylist(t);
                  setIsPlaylistModalOpen(true);
                }}
              />
            ))}
          </div>
        )}
      </section>

      {/* Playlist modal */}
      <PlaylistModal
        isOpen={isPlaylistModalOpen}
        onClose={() => setIsPlaylistModalOpen(false)}
        selectedTrack={selectedTrackForPlaylist}
      />
    </div>
  );
}

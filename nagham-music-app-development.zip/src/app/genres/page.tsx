"use client";

import React, { useState } from "react";
import { GENRES } from "@/lib/constants";
import { GenreGrid } from "@/components/GenreGrid";
import { Layers, Sparkles, Music } from "lucide-react";
import { MusicLanguage } from "@/lib/types";

export default function GenresPage() {
  const [langFilter, setLangFilter] = useState<MusicLanguage>("all");

  return (
    <div className="flex flex-col gap-8">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#12121a] via-[#161622] to-emerald-950/30 border border-white/[0.08] p-6 sm:p-8 shadow-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-500/20 shrink-0">
            <Layers className="w-7 h-7 text-zinc-950 font-black" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-black text-white">الأنواع والتصنيفات الموسيقية</h1>
            <p className="text-xs sm:text-sm text-zinc-400 mt-1">
              استكشف آلاف الأغاني والمقاطع المصنفة بدقة حسب الأسلوب والإحساس
            </p>
          </div>
        </div>

        {/* Filter buttons */}
        <div className="flex items-center bg-[#121218]/90 p-1 rounded-2xl border border-white/[0.08] text-xs">
          <button
            onClick={() => setLangFilter("all")}
            className={`px-4 py-2 rounded-xl transition-all duration-200 font-bold ${
              langFilter === "all" ? "bg-gradient-to-r from-emerald-500 to-teal-400 text-zinc-950 shadow-md shadow-emerald-500/20" : "text-zinc-400 hover:text-white"
            }`}
          >
            الكل
          </button>
          <button
            onClick={() => setLangFilter("arabic")}
            className={`px-4 py-2 rounded-xl transition-all duration-200 font-bold ${
              langFilter === "arabic" ? "bg-gradient-to-r from-emerald-500 to-teal-400 text-zinc-950 shadow-md shadow-emerald-500/20" : "text-zinc-400 hover:text-white"
            }`}
          >
            عربي
          </button>
          <button
            onClick={() => setLangFilter("international")}
            className={`px-4 py-2 rounded-xl transition-all duration-200 font-bold ${
              langFilter === "international" ? "bg-gradient-to-r from-emerald-500 to-teal-400 text-zinc-950 shadow-md shadow-emerald-500/20" : "text-zinc-400 hover:text-white"
            }`}
          >
            عالمي
          </button>
        </div>
      </div>

      {/* Grid of Genre Cards */}
      <GenreGrid filterLanguage={langFilter} />

      {/* Detailed Breakdown Section */}
      <div className="flex flex-col gap-4 mt-4">
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-emerald-400" />
          <span>تفاصيل التصنيفات وأشهر الفنانين</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {GENRES.map((g) => (
            <div key={g.id} className="p-5 rounded-3xl bg-[#121218]/60 hover:bg-[#181824] border border-white/[0.08] flex flex-col gap-2.5 transition shadow-lg">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-white text-base">{g.title}</h3>
                <span className="text-xs text-zinc-400 font-mono bg-white/[0.04] px-2.5 py-0.5 rounded-md border border-white/[0.04]">{g.titleEn}</span>
              </div>
              <p className="text-xs text-zinc-300 leading-relaxed">{g.description}</p>
              <div className="flex flex-wrap gap-1.5 mt-2">
                {g.featuredArtists.map((artistName) => (
                  <span
                    key={artistName}
                    className="text-[11px] bg-white/[0.04] text-zinc-300 px-3 py-1 rounded-full border border-white/[0.06] font-medium"
                  >
                    {artistName}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

"use client";

import React, { useState, useEffect, use } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Playlist, Track } from "@/lib/types";
import { usePlayer } from "@/context/PlayerContext";
import { TrackCard } from "@/components/TrackCard";
import { PlaylistModal } from "@/components/PlaylistModal";
import {
  Play,
  Shuffle,
  ChevronLeft,
  ListMusic,
  Trash2,
  Sparkles,
  Music,
} from "lucide-react";

export default function PlaylistDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const resolvedParams = use(params);
  const playlistId = resolvedParams.id;
  const router = useRouter();
  const { playTrack } = usePlayer();

  const [playlist, setPlaylist] = useState<Playlist | null>(null);
  const [tracks, setTracks] = useState<Track[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTrackForPlaylist, setSelectedTrackForPlaylist] = useState<Track | null>(null);
  const [isPlaylistModalOpen, setIsPlaylistModalOpen] = useState(false);

  useEffect(() => {
    fetchPlaylist();
  }, [playlistId]);

  const fetchPlaylist = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/playlists/${playlistId}`);
      const data = await res.json();
      if (data.success && data.data) {
        setPlaylist(data.data.playlist);
        setTracks(data.data.tracks || []);
      }
    } catch (err) {
      console.error("Error loading playlist:", err);
    } finally {
      setLoading(false);
    }
  };

  const handlePlayAll = (shuffle: boolean = false) => {
    if (tracks.length === 0) return;
    const queueToPlay = shuffle ? [...tracks].sort(() => Math.random() - 0.5) : tracks;
    playTrack(queueToPlay[0], queueToPlay);
  };

  const handleDeletePlaylist = async () => {
    if (!confirm("هل أنت متأكد من حذف قائمة التشغيل هذه؟")) return;
    try {
      const res = await fetch(`/api/playlists/${playlistId}`, { method: "DELETE" });
      const data = await res.json();
      if (data.success) {
        router.push("/library");
      } else {
        alert(data.error || "تعذر حذف القائمة");
      }
    } catch {
      alert("حدث خطأ أثناء الحذف");
    }
  };

  return (
    <div className="flex flex-col gap-8">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-xs text-zinc-400 font-medium">
        <Link href="/" className="hover:text-emerald-400 transition">الرئيسية</Link>
        <ChevronLeft className="w-3.5 h-3.5 rtl:rotate-180 text-zinc-600" />
        <Link href="/library" className="hover:text-emerald-400 transition">مكتبتي</Link>
        <ChevronLeft className="w-3.5 h-3.5 rtl:rotate-180 text-zinc-600" />
        <span className="text-white font-bold">{playlist?.name || "قائمة تشغيل"}</span>
      </div>

      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#12121a] via-[#161622] to-emerald-950/40 border border-white/[0.08] p-6 sm:p-8 shadow-2xl">
        <div className="relative z-10 flex flex-col sm:flex-row items-center gap-6 sm:gap-8">
          <div className="w-36 h-36 sm:w-48 sm:h-48 rounded-3xl overflow-hidden shrink-0 border-2 border-white/[0.1] shadow-2xl bg-zinc-900 flex items-center justify-center">
            {playlist?.coverUrl ? (
              <img src={playlist.coverUrl} alt={playlist.name} className="w-full h-full object-cover" />
            ) : (
              <ListMusic className="w-16 h-16 text-emerald-400" />
            )}
          </div>

          <div className="text-right flex-1">
            <span className="text-xs bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 px-3.5 py-1 rounded-full font-bold inline-block mb-2 shadow-sm">
              {playlist?.isSystem ? "قائمة رسمية من نغم" : "قائمة مخصصة"}
            </span>

            <h1 className="text-2xl sm:text-4xl font-black text-white">{playlist?.name || "قائمة التشغيل"}</h1>
            <p className="text-sm sm:text-base text-zinc-300 mt-2 max-w-xl font-medium">{playlist?.description || "مجموعة مختارة من الأغاني الكاملة"}</p>

            <div className="text-xs text-zinc-400 my-4 flex items-center gap-3 font-semibold">
              <span className="text-emerald-400">{tracks.length} أغنية كاملة</span>
              <span>•</span>
              <span className="text-zinc-300">تشغيل متواصل بدون توقف</span>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <button
                onClick={() => handlePlayAll(false)}
                disabled={tracks.length === 0}
                className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-zinc-950 font-black text-sm flex items-center gap-2.5 shadow-xl shadow-emerald-500/25 hover:scale-105 active:scale-95 transition disabled:opacity-50"
              >
                <Play className="w-5 h-5 fill-zinc-950" />
                <span>تشغيل الكل ({tracks.length})</span>
              </button>

              <button
                onClick={() => handlePlayAll(true)}
                disabled={tracks.length === 0}
                className="px-5 py-3.5 rounded-2xl bg-[#1a1a26] hover:bg-[#222234] text-zinc-200 text-xs font-bold flex items-center gap-2 border border-white/[0.08] transition disabled:opacity-50"
              >
                <Shuffle className="w-4 h-4 text-emerald-400" />
                <span>تشغيل عشوائي</span>
              </button>

              {!playlist?.isSystem && (
                <button
                  onClick={handleDeletePlaylist}
                  className="px-3.5 py-3.5 rounded-2xl bg-rose-950/40 hover:bg-rose-900/60 text-rose-400 border border-rose-800/40 text-xs transition"
                  title="حذف القائمة"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Tracks List */}
      <section className="flex flex-col gap-4">
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          <Music className="w-5 h-5 text-emerald-400" />
          <span>الأغاني في هذه القائمة ({tracks.length})</span>
        </h2>

        {loading ? (
          <div className="p-12 text-center text-zinc-500 text-sm">جاري تحميل الأغاني...</div>
        ) : tracks.length === 0 ? (
          <div className="p-16 text-center bg-[#121218]/40 rounded-3xl border border-white/[0.08] flex flex-col items-center gap-2">
            <Sparkles className="w-12 h-12 text-zinc-600 mb-1" />
            <h3 className="text-base font-bold text-white">لا توجد أغاني في هذه القائمة بعد</h3>
            <p className="text-xs text-zinc-400">تصفح الأغاني وأضف مقاطعك المفضلة إلى هذه القائمة.</p>
            <Link
              href="/"
              className="mt-2 px-5 py-2.5 bg-emerald-500 text-zinc-950 text-xs font-bold rounded-2xl hover:bg-emerald-400 transition"
            >
              استكشف الأغاني
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5">
            {tracks.map((track, idx) => (
              <TrackCard
                key={`${track.trackId}_${idx}`}
                track={track}
                trackList={tracks}
                viewMode="list"
                index={idx}
                onAddToPlaylist={(t) => {
                  setSelectedTrackForPlaylist(t);
                  setIsPlaylistModalOpen(true);
                }}
              />
            ))}
          </div>
        )}
      </section>

      {/* Playlist modal */}
      <PlaylistModal
        isOpen={isPlaylistModalOpen}
        onClose={() => setIsPlaylistModalOpen(false)}
        selectedTrack={selectedTrackForPlaylist}
        onPlaylistCreated={fetchPlaylist}
      />
    </div>
  );
}

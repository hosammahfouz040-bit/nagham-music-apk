"use client";

import React, { useState, useEffect, use } from "react";
import Link from "next/link";
import { Album, Track } from "@/lib/types";
import { usePlayer } from "@/context/PlayerContext";
import { TrackCard } from "@/components/TrackCard";
import { PlaylistModal } from "@/components/PlaylistModal";
import {
  Play,
  Shuffle,
  ChevronLeft,
  Disc3,
  Calendar,
  Music,
} from "lucide-react";

export default function AlbumDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const resolvedParams = use(params);
  const albumId = resolvedParams.id;
  const { playTrack } = usePlayer();

  const [album, setAlbum] = useState<Album | null>(null);
  const [tracks, setTracks] = useState<Track[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTrackForPlaylist, setSelectedTrackForPlaylist] = useState<Track | null>(null);
  const [isPlaylistModalOpen, setIsPlaylistModalOpen] = useState(false);

  useEffect(() => {
    fetchAlbumTracks();
  }, [albumId]);

  const fetchAlbumTracks = async () => {
    setLoading(true);
    try {
      const cleanId = decodeURIComponent(albumId);
      const res = await fetch(`/api/search?q=${encodeURIComponent(cleanId.replace("album_", "").replace(/_/g, " "))}`);
      const data = await res.json();
      if (data.success && data.data?.tracks?.length > 0) {
        const foundTracks = data.data.tracks;
        setTracks(foundTracks);
        const first = foundTracks[0];
        setAlbum({
          id: albumId,
          title: first.albumName || first.title,
          artistName: first.artistName,
          coverUrl: first.artworkUrl,
          releaseYear: first.releaseDate ? new Date(first.releaseDate).getFullYear().toString() : "2024",
          genre: first.genre,
          genreCategory: first.genreCategory,
          language: first.language,
          totalTracks: foundTracks.length,
        });
      }
    } catch (err) {
      console.error("Error loading album tracks:", err);
    } finally {
      setLoading(false);
    }
  };

  const handlePlayAll = (shuffle: boolean = false) => {
    if (tracks.length === 0) return;
    const queueToPlay = shuffle ? [...tracks].sort(() => Math.random() - 0.5) : tracks;
    playTrack(queueToPlay[0], queueToPlay);
  };

  return (
    <div className="flex flex-col gap-8">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-xs text-zinc-400 font-medium">
        <Link href="/" className="hover:text-emerald-400 transition">الرئيسية</Link>
        <ChevronLeft className="w-3.5 h-3.5 rtl:rotate-180 text-zinc-600" />
        <Link href="/albums" className="hover:text-emerald-400 transition">الألبومات</Link>
        <ChevronLeft className="w-3.5 h-3.5 rtl:rotate-180 text-zinc-600" />
        <span className="text-white font-bold">{album?.title || "تفاصيل الألبوم"}</span>
      </div>

      {/* Album Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#12121a] via-[#161622] to-indigo-950/40 border border-white/[0.08] p-6 sm:p-8 shadow-2xl">
        <div className="relative z-10 flex flex-col sm:flex-row items-center gap-6 sm:gap-8">
          <div className="w-40 h-40 sm:w-52 sm:h-52 rounded-3xl overflow-hidden shrink-0 border-2 border-white/[0.1] shadow-2xl shadow-black/80">
            {album?.coverUrl ? (
              <img src={album.coverUrl} alt={album.title} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full bg-zinc-900 flex items-center justify-center">
                <Disc3 className="w-16 h-16 text-zinc-600" />
              </div>
            )}
          </div>

          <div className="text-right flex-1">
            <span className="text-xs bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 px-3.5 py-1 rounded-full font-bold inline-block mb-2 shadow-sm">
              ألبوم رسمي كامل
            </span>

            <h1 className="text-2xl sm:text-4xl font-black text-white">{album?.title || "ألبوم موسيقي"}</h1>
            <p className="text-base sm:text-lg text-zinc-300 font-semibold mt-1">{album?.artistName}</p>

            <div className="flex items-center gap-4 text-xs text-zinc-400 my-4 font-medium">
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                {album?.releaseYear}
              </span>
              <span>•</span>
              <span>{album?.genre || "موسيقى"}</span>
              <span>•</span>
              <span className="text-emerald-400 font-bold">{tracks.length} مقطع كامل</span>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => handlePlayAll(false)}
                disabled={tracks.length === 0}
                className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-zinc-950 font-black text-sm flex items-center gap-2.5 shadow-xl shadow-emerald-500/25 hover:scale-105 active:scale-95 transition disabled:opacity-50"
              >
                <Play className="w-5 h-5 fill-zinc-950" />
                <span>تشغيل الألبوم ({tracks.length})</span>
              </button>

              <button
                onClick={() => handlePlayAll(true)}
                disabled={tracks.length === 0}
                className="px-5 py-3.5 rounded-2xl bg-[#1a1a26] hover:bg-[#222234] text-zinc-200 text-xs font-bold flex items-center gap-2 border border-white/[0.08] transition disabled:opacity-50"
              >
                <Shuffle className="w-4 h-4 text-emerald-400" />
                <span>تشغيل عشوائي</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Tracks List */}
      <section className="flex flex-col gap-4">
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          <Music className="w-5 h-5 text-emerald-400" />
          <span>محتويات الألبوم ({tracks.length} أغنية كاملة)</span>
        </h2>

        {loading ? (
          <div className="p-12 text-center text-zinc-500 text-sm">جاري تحميل مقاطع الألبوم...</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5">
            {tracks.map((track, idx) => (
              <TrackCard
                key={track.trackId}
                track={track}
                trackList={tracks}
                viewMode="list"
                index={idx}
                onAddToPlaylist={(t) => {
                  setSelectedTrackForPlaylist(t);
                  setIsPlaylistModalOpen(true);
                }}
              />
            ))}
          </div>
        )}
      </section>

      {/* Playlist modal */}
      <PlaylistModal
        isOpen={isPlaylistModalOpen}
        onClose={() => setIsPlaylistModalOpen(false)}
        selectedTrack={selectedTrackForPlaylist}
      />
    </div>
  );
}

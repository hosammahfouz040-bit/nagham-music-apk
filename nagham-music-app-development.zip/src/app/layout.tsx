import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { PlayerProvider } from "@/context/PlayerContext";
import { Navbar } from "@/components/Navbar";
import { MiniPlayer } from "@/components/MiniPlayer";
import { FullPlayerModal } from "@/components/FullPlayerModal";
import { SourceModalContainer } from "@/components/SourceModalContainer";
import { BottomNav } from "@/components/BottomNav";
import { ServiceWorkerRegister } from "@/components/ServiceWorkerRegister";

export const metadata: Metadata = {
  title: "نغم | Nagham - استكشاف وتشغيل الموسيقى العربية والمصرية بدون إنترنت",
  description:
    "استمع إلى روائع الطرب العربي والشعبي والمهرجانات والراب والبوب والموسيقى المصرية والعالمية كاملة مع دعم التشغيل بدون إنترنت وتحميل تطبيق APK للأندرويد.",
  keywords: ["موسيقى عربية", "أغاني مصرية", "طرب", "مهرجانات", "راب عربي", "تحميل APK", "Nagham Music", "تشغيل بدون إنترنت"],
  applicationName: "نغم | Nagham",
  appleWebApp: {
    capable: true,
    title: "نغم Nagham",
    statusBarStyle: "black-translucent",
  },
};

export const viewport: Viewport = {
  themeColor: "#050507",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700;800;900&family=Tajawal:wght@400;500;700;800&display=swap"
          rel="stylesheet"
        />
        <link rel="manifest" href="/manifest.json" />
      </head>
      <body className="bg-[#050507] text-[#f5f5f7] font-['Cairo',sans-serif] antialiased selection:bg-emerald-500 selection:text-zinc-950 min-h-screen flex flex-col pb-28 md:pb-24">
        <PlayerProvider>
          <ServiceWorkerRegister />
          <Navbar />
          <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            {children}
          </main>
          <MiniPlayer />
          <FullPlayerModal />
          <SourceModalContainer />
          <BottomNav />
        </PlayerProvider>
      </body>
    </html>
  );
}

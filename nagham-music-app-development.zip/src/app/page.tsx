"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { Track, Artist, Playlist, GenreCategory, MusicLanguage } from "@/lib/types";
import { usePlayer } from "@/context/PlayerContext";
import { TrackCard } from "@/components/TrackCard";
import { ArtistCard } from "@/components/ArtistCard";
import { GenreGrid } from "@/components/GenreGrid";
import { PlaylistModal } from "@/components/PlaylistModal";
import { AudioVisualizer } from "@/components/AudioVisualizer";
import {
  Play,
  Sparkles,
  Flame,
  Mic2,
  Heart,
  ChevronLeft,
  ChevronDown,
  ChevronUp,
  Disc3,
  Layers,
  Radio,
  Coffee,
  Globe,
  Plus,
  Music,
  Compass,
  TrendingUp,
  Headphones,
  Award,
  ArrowDownToLine,
  Smartphone,
  WifiOff,
} from "lucide-react";

export default function HomePage() {
  const { playTrack, currentTrack, isPlaying } = usePlayer();
  const [activeLang, setActiveLang] = useState<MusicLanguage>("all");
  const [trendingTracks, setTrendingTracks] = useState<Track[]>([]);
  const [egyptianPulseTracks, setEgyptianPulseTracks] = useState<Track[]>([]);
  const [nostalgia90sTracks, setNostalgia90sTracks] = useState<Track[]>([]);
  const [tarabTracks, setTarabTracks] = useState<Track[]>([]);
  const [khaleejiTracks, setKhaleejiTracks] = useState<Track[]>([]);
  const [shaabiTracks, setShaabiTracks] = useState<Track[]>([]);
  const [rapTracks, setRapTracks] = useState<Track[]>([]);
  const [popTracks, setPopTracks] = useState<Track[]>([]);
  const [calmTracks, setCalmTracks] = useState<Track[]>([]);
  const [artistsList, setArtistsList] = useState<Artist[]>([]);
  const [playlistsList, setPlaylistsList] = useState<Playlist[]>([]);
  const [selectedTrackForPlaylist, setSelectedTrackForPlaylist] = useState<Track | null>(null);
  const [isPlaylistModalOpen, setIsPlaylistModalOpen] = useState(false);
  const [heroSlideIdx, setHeroSlideIdx] = useState(0);
  const [loading, setLoading] = useState(true);

  // Expand toggles for each category
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({});

  useEffect(() => {
    loadData();
  }, [activeLang]);

  const loadData = async () => {
    setLoading(true);
    try {
      const langParam = activeLang !== "all" ? `&language=${activeLang}` : "";

      const [tracksRes, artistsRes, playlistsRes] = await Promise.all([
        fetch(`/api/tracks?limit=500${langParam}`),
        fetch(`/api/artists?limit=200${langParam}`),
        fetch(`/api/playlists`),
      ]);

      const [tracksData, artistsData, playlistsData] = await Promise.all([
        tracksRes.json(),
        artistsRes.json(),
        playlistsRes.json(),
      ]);

      if (tracksData.success && Array.isArray(tracksData.data)) {
        const all: Track[] = tracksData.data;
        setTrendingTracks(all.slice(0, 12));

        // Filter Egyptian Pulse (Cairokee, Hamza Namira, Ahmed Saad, Tul8te, Ruby, Ramadan, Amr Diab, Wegz, Sherine, Hamaki, Haitham Shaker, Wama, etc.)
        const isEgyptian = (t: Track) => {
          const text = `${t.artistName} ${t.title}`.toLowerCase();
          return (
            text.includes("عمرو دياب") ||
            text.includes("كايروكي") ||
            text.includes("حمزة نمرة") ||
            text.includes("أحمد سعد") ||
            text.includes("توليت") ||
            text.includes("روبي") ||
            text.includes("محمد رمضان") ||
            text.includes("ويجز") ||
            text.includes("شيرين") ||
            text.includes("حماقي") ||
            text.includes("تامر حسني") ||
            text.includes("بهاء سلطان") ||
            text.includes("مسار إجباري") ||
            text.includes("شارموفرز") ||
            text.includes("عصام صاصا") ||
            text.includes("شاكوش") ||
            text.includes("حكيم") ||
            text.includes("عدوية") ||
            text.includes("منير") ||
            text.includes("فريد") ||
            text.includes("مصطفى حجاج") ||
            text.includes("أبو") ||
            text.includes("شفيقة") ||
            text.includes("أحمد كامل") ||
            text.includes("هيثم شاكر") ||
            text.includes("خالد سليم") ||
            text.includes("واما") ||
            text.includes("مي فاروق") ||
            text.includes("ريهام عبد الحكيم") ||
            text.includes("ياسمين علي") ||
            text.includes("دياب") ||
            text.includes("عصام كاريكا") ||
            text.includes("أحمد بتشان") ||
            text.includes("الشرنوبي") ||
            text.includes("عمر خيرت") ||
            text.includes("حسن الأسمر") ||
            text.includes("محمد فؤاد") ||
            text.includes("سيد مكاوي") ||
            text.includes("عمار الشريعي") ||
            text.includes("الشامي") ||
            t.genreCategory === "shaabi" ||
            t.genreCategory === "mahraganat"
          );
        };

        setEgyptianPulseTracks(all.filter(isEgyptian));

        // 90s Nostalgia Egyptian Hits
        const is90s = (t: Track) => {
          const text = `${t.artistName} ${t.title}`.toLowerCase();
          return (
            text.includes("إيهاب توفيق") ||
            text.includes("مصطفى قمر") ||
            text.includes("حميد الشاعري") ||
            text.includes("هشام عباس") ||
            text.includes("علاء عبد الخالق") ||
            text.includes("حسام حسني") ||
            text.includes("محمد الحلو") ||
            text.includes("خالد عجاج") ||
            text.includes("محمد محيي") ||
            text.includes("عامر منيب") ||
            text.includes("حسام حبيب") ||
            text.includes("مدحت صالح") ||
            text.includes("علي الحجار") ||
            text.includes("هاني شاكر") ||
            text.includes("محمد فؤاد") ||
            text.includes("عمرو دياب") ||
            text.includes("لؤي")
          );
        };
        setNostalgia90sTracks(all.filter(is90s));

        setTarabTracks(all.filter((t) => t.genreCategory === "tarab"));
        setKhaleejiTracks(all.filter((t) => t.genreCategory === "khaleeji"));
        setShaabiTracks(all.filter((t) => t.genreCategory === "shaabi" || t.genreCategory === "mahraganat"));
        setRapTracks(all.filter((t) => t.genreCategory === "rap"));
        setPopTracks(all.filter((t) => t.genreCategory === "pop"));
        setCalmTracks(all.filter((t) => t.genreCategory === "calm"));
      }

      if (artistsData.success && Array.isArray(artistsData.data)) {
        setArtistsList(artistsData.data);
      }

      if (playlistsData.success && Array.isArray(playlistsData.data)) {
        setPlaylistsList(playlistsData.data);
      }
    } catch (err) {
      console.warn("Network error loading home data, falling back to local offline store:", err);
      // Fallback to local IndexedDB
      try {
        const { getOfflineTracks, getOfflineArtists } = await import("@/lib/offline-store");
        const [offlineTracks, offlineArtists] = await Promise.all([
          getOfflineTracks({ language: activeLang, limit: 300 }),
          getOfflineArtists({ language: activeLang, limit: 100 }),
        ]);

        if (offlineTracks.length > 0) {
          setTrendingTracks(offlineTracks.slice(0, 12));
          setTarabTracks(offlineTracks.filter((t) => t.genreCategory === "tarab"));
          setKhaleejiTracks(offlineTracks.filter((t) => t.genreCategory === "khaleeji"));
          setShaabiTracks(offlineTracks.filter((t) => t.genreCategory === "shaabi" || t.genreCategory === "mahraganat"));
          setRapTracks(offlineTracks.filter((t) => t.genreCategory === "rap"));
          setPopTracks(offlineTracks.filter((t) => t.genreCategory === "pop"));
          setCalmTracks(offlineTracks.filter((t) => t.genreCategory === "calm"));
        }
        if (offlineArtists.length > 0) {
          setArtistsList(offlineArtists);
        }
      } catch (offlineErr) {
        console.error("Offline store read failed:", offlineErr);
      }
    } finally {
      setLoading(false);
    }
  };

  const toggleSection = (sec: string) => {
    setExpandedSections((prev) => ({ ...prev, [sec]: !prev[sec] }));
  };

  // Hero Spotlight Tracks
  const heroSpotlightPool = trendingTracks.length > 0 ? trendingTracks.slice(0, 5) : [];
  const currentHeroTrack = heroSpotlightPool[heroSlideIdx % (heroSpotlightPool.length || 1)] || null;

  return (
    <div className="flex flex-col gap-10">
      {/* 1. Language Toggle & Filter Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/[0.08] pb-4">
        <div className="flex items-center gap-2">
          <span className="text-xs text-zinc-400 font-bold flex items-center gap-1.5">
            <Compass className="w-3.5 h-3.5 text-emerald-400" />
            <span>عرض المحتوى:</span>
          </span>
          <div className="flex items-center bg-[#121218]/90 p-1 rounded-2xl border border-white/[0.08] text-xs">
            <button
              onClick={() => setActiveLang("all")}
              className={`px-3.5 py-1.5 rounded-xl transition-all duration-200 font-bold ${
                activeLang === "all"
                  ? "bg-gradient-to-r from-emerald-500 to-teal-400 text-zinc-950 shadow-md shadow-emerald-500/20"
                  : "text-zinc-400 hover:text-white"
              }`}
            >
              الكل (عربي وعالمي)
            </button>
            <button
              onClick={() => setActiveLang("arabic")}
              className={`px-3.5 py-1.5 rounded-xl transition-all duration-200 font-bold ${
                activeLang === "arabic"
                  ? "bg-gradient-to-r from-emerald-500 to-teal-400 text-zinc-950 shadow-md shadow-emerald-500/20"
                  : "text-zinc-400 hover:text-white"
              }`}
            >
              الأغاني والموسيقى العربية
            </button>
            <button
              onClick={() => setActiveLang("international")}
              className={`px-3.5 py-1.5 rounded-xl transition-all duration-200 font-bold ${
                activeLang === "international"
                  ? "bg-gradient-to-r from-emerald-500 to-teal-400 text-zinc-950 shadow-md shadow-emerald-500/20"
                  : "text-zinc-400 hover:text-white"
              }`}
            >
              الأغاني العالمية
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Link
            href="/search"
            className="text-xs text-emerald-400 hover:text-emerald-300 flex items-center gap-1.5 font-bold bg-emerald-500/10 px-3.5 py-1.5 rounded-xl border border-emerald-500/20 transition-all hover:bg-emerald-500/20"
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>البحث والاستكشاف المتقدم</span>
            <ChevronLeft className="w-4 h-4 rtl:rotate-180" />
          </Link>
        </div>
      </div>

      {/* 2. Luxury Glass Spotlight Stage (Interactive Hero Carousel) */}
      {currentHeroTrack && (
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#12121a] via-[#161622] to-emerald-950/40 border border-white/[0.1] p-6 sm:p-8 lg:p-10 shadow-2xl shadow-black/80">
          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
            {/* Right: Info with Audio Visualizer */}
            <div className="text-right flex-1 max-w-xl">
              <div className="flex items-center gap-2.5 mb-3">
                <span className="inline-flex items-center gap-1.5 bg-gradient-to-r from-emerald-500/20 to-teal-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-bold px-3 py-1 rounded-full shadow-sm">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                  <span>المسار المميز لليوم</span>
                </span>
                <span className="text-[11px] font-bold text-zinc-400 bg-white/[0.06] px-2.5 py-0.5 rounded-full border border-white/[0.06]">
                  أغنية كاملة 100%
                </span>
              </div>

              <h1 className="text-2xl sm:text-4xl lg:text-5xl font-black text-white leading-tight mb-2 tracking-tight">
                {currentHeroTrack.title}
              </h1>
              <p className="text-base sm:text-xl text-zinc-300 font-semibold mb-4">
                {currentHeroTrack.artistName}
              </p>

              <p className="text-xs sm:text-sm text-zinc-400 mb-6 leading-relaxed">
                استمع إلى الأغنية كاملة من بدايتها إلى نهايتها بصوت نقي عالي الجودة عبر مشغل نغم الداخلي المباشر، مع ميزة التقديم والترجيع ومؤقت النوم.
              </p>

              <div className="flex flex-wrap items-center gap-3">
                <button
                  onClick={() => playTrack(currentHeroTrack, trendingTracks, "full")}
                  className="px-7 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-400 hover:from-emerald-400 hover:to-teal-300 text-zinc-950 font-black text-sm flex items-center gap-2.5 shadow-xl shadow-emerald-500/25 hover:scale-105 active:scale-95 transition-all duration-200"
                >
                  <Play className="w-5 h-5 fill-zinc-950" />
                  <span>
                    {currentTrack?.trackId === currentHeroTrack.trackId && isPlaying
                      ? "جاري التشغيل الآن"
                      : "استمع للأغنية كاملة"}
                  </span>
                </button>

                <Link
                  href={`/genres/${currentHeroTrack.genreCategory}`}
                  className="px-4 py-3.5 rounded-2xl bg-[#1e1e2c] hover:bg-[#28283a] text-zinc-200 text-xs font-bold border border-white/[0.08] hover:border-emerald-500/30 transition-all duration-200"
                >
                  استكشف قسم {currentHeroTrack.genre}
                </Link>
              </div>

              {/* Slide Switcher Dots */}
              {heroSpotlightPool.length > 1 && (
                <div className="flex items-center gap-2 mt-6">
                  {heroSpotlightPool.map((_, idx) => (
                    <button
                      key={idx}
                      onClick={() => setHeroSlideIdx(idx)}
                      className={`h-2 rounded-full transition-all duration-300 ${
                        idx === heroSlideIdx ? "w-8 bg-emerald-400" : "w-2 bg-white/20 hover:bg-white/40"
                      }`}
                      title={`عرض المسار ${idx + 1}`}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* Left: Artwork Spotlight with Glowing Record */}
            <div className="relative shrink-0 group">
              <div className="w-48 h-48 sm:w-64 sm:h-64 rounded-3xl overflow-hidden shadow-2xl shadow-emerald-950/40 border-2 border-white/[0.1] group-hover:border-emerald-500/40 transition-all duration-500">
                <img
                  src={currentHeroTrack.artworkUrl}
                  alt={currentHeroTrack.title}
                  className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-700 ease-out"
                />
              </div>

              {/* Playing indicator badge */}
              {currentTrack?.trackId === currentHeroTrack.trackId && isPlaying && (
                <div className="absolute bottom-3 left-3 bg-zinc-950/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-emerald-500/40 flex items-center gap-2 shadow-xl">
                  <AudioVisualizer isPlaying={isPlaying} barCount={4} />
                  <span className="text-[11px] font-bold text-emerald-400">مشغل الآن</span>
                </div>
              )}
            </div>
          </div>

          {/* Decorative ambient radial light */}
          <div className="absolute -top-24 -left-24 w-96 h-96 bg-emerald-500/15 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
        </div>
      )}

      {/* Offline App & APK Download Prompt Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#12121e] via-[#171728] to-emerald-950/30 border border-white/[0.08] p-5 sm:p-6 shadow-xl flex flex-col md:flex-row items-center justify-between gap-5">
        <div className="flex items-center gap-4 text-right">
          <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-500/20 shrink-0">
            <Smartphone className="w-6 h-6 sm:w-7 sm:h-7 text-zinc-950 font-black" />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] sm:text-xs font-bold text-emerald-300 bg-emerald-950/80 px-2.5 py-0.5 rounded-full border border-emerald-500/30">
                تطبيق أندرويد APK متاح الآن
              </span>
              <span className="text-[10px] text-amber-300 font-bold bg-amber-950/60 px-2 py-0.5 rounded-full border border-amber-500/30 flex items-center gap-1">
                <WifiOff className="w-2.5 h-2.5" />
                يعمل بدون إنترنت
              </span>
            </div>
            <h3 className="text-base sm:text-lg font-black text-white">حمّل تطبيق نغم بصيغة APK واستمع لجميع الأغاني أوفلاين</h3>
            <p className="text-xs text-zinc-400 mt-0.5">افتح مكتبتك واستمع لآلاف الأغاني المصرية والعربية كاملة حتى في وضع الطيران.</p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 w-full md:w-auto shrink-0 justify-end">
          <a
            href="/Nagham-Music-v2.0.apk"
            download="Nagham-Music-v2.0.apk"
            className="flex-1 md:flex-none px-5 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-zinc-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 hover:scale-105 active:scale-95 transition-all cursor-pointer"
            title="تحميل مباشر لملف APK"
          >
            <ArrowDownToLine className="w-4 h-4 stroke-[2.5]" />
            <span>تحميل APK مباشر</span>
          </a>
          <Link
            href="/download"
            className="px-4 py-3 rounded-2xl bg-[#1e1e2c] hover:bg-[#28283a] text-zinc-200 text-xs font-bold border border-white/[0.08] transition"
          >
            صفحة التثبيت
          </Link>
        </div>
      </div>

      {/* 3. Genres Taxonomy Grid */}
      <section className="flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Layers className="w-5 h-5 text-emerald-400" />
            <h2 className="text-lg sm:text-xl font-black text-white">الأنواع والتصنيفات الموسيقية</h2>
          </div>
          <Link href="/genres" className="text-xs text-emerald-400 hover:underline flex items-center gap-1 font-bold">
            <span>كل الأنواع ({10})</span>
            <ChevronLeft className="w-4 h-4 rtl:rotate-180" />
          </Link>
        </div>

        <GenreGrid filterLanguage={activeLang} limit={10} />
      </section>

      {/* 4. نبض الموسيقى والأغاني المصرية الكبرى (Egyptian Music Pulse) */}
      {egyptianPulseTracks.length > 0 && (
        <section className="flex flex-col gap-4 bg-[#0d0d14]/70 p-4 sm:p-6 rounded-3xl border border-white/[0.08] shadow-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center shadow-md">
                <Flame className="w-4 h-4 text-zinc-950 font-black" />
              </div>
              <div>
                <h2 className="text-lg sm:text-xl font-black text-white">نبض الأغنية المصرية - هيتس وتوب ترند</h2>
                <p className="text-[11px] text-zinc-400">محمد منير، شفيقة، كايروكي، حمزة نمرة، أحمد سعد، توليت، روبي، رمضان، ويجز، حماقي، وشيرين</p>
              </div>
            </div>
            <Link href="/search?q=مصر" className="text-xs text-amber-400 hover:underline flex items-center gap-1 font-bold">
              <span>المزيد من المصري</span>
              <ChevronLeft className="w-4 h-4 rtl:rotate-180" />
            </Link>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {(expandedSections["egyptian_pulse"] ? egyptianPulseTracks : egyptianPulseTracks.slice(0, 12)).map((track) => (
              <TrackCard
                key={track.trackId}
                track={track}
                trackList={egyptianPulseTracks}
                viewMode="grid"
                onAddToPlaylist={(t) => {
                  setSelectedTrackForPlaylist(t);
                  setIsPlaylistModalOpen(true);
                }}
              />
            ))}
          </div>

          {egyptianPulseTracks.length > 12 && (
            <button
              onClick={() => toggleSection("egyptian_pulse")}
              className="mt-2 py-2.5 px-4 rounded-2xl bg-[#161622] hover:bg-[#1e1e30] text-zinc-300 text-xs font-bold flex items-center justify-center gap-1.5 border border-white/[0.08] transition"
            >
              <span>
                {expandedSections["egyptian_pulse"]
                  ? "عرض أقل"
                  : `عرض المزيد من الأغاني المصرية الحديثة (${egyptianPulseTracks.length - 12}+)`}
              </span>
              {expandedSections["egyptian_pulse"] ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
          )}
        </section>
      )}

      {/* 5. Trending Tracks Grid (الأكثر استماعاً الآن) */}
      {trendingTracks.length > 0 && (
        <section className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <TrendingUp className="w-5 h-5 text-emerald-400" />
              <h2 className="text-lg sm:text-xl font-black text-white">الأكثر شعبية والأعلى استماعاً</h2>
            </div>
            <span className="text-xs text-zinc-400 font-medium">أحدث الأعمال الموسيقية المتصدرة</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-4">
            {trendingTracks.map((track) => (
              <TrackCard
                key={track.trackId}
                track={track}
                trackList={trendingTracks}
                viewMode="grid"
                onAddToPlaylist={(t) => {
                  setSelectedTrackForPlaylist(t);
                  setIsPlaylistModalOpen(true);
                }}
              />
            ))}
          </div>
        </section>
      )}

      {/* 6. نوستالجيا كاسيت التسعينات والجيل الذهبي المصري */}
      {nostalgia90sTracks.length > 0 && (
        <section className="flex flex-col gap-4 bg-[#0d0d14]/70 p-4 sm:p-6 rounded-3xl border border-white/[0.08] shadow-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-500 flex items-center justify-center shadow-md">
                <Disc3 className="w-4 h-4 text-zinc-950 font-black" />
              </div>
              <div>
                <h2 className="text-lg sm:text-xl font-black text-white">نوستالجيا كاسيت التسعينات والجيل الذهبي</h2>
                <p className="text-[11px] text-zinc-400">إيهاب توفيق، مصطفى قمر، حميد الشاعري، هشام عباس، مدحت صالح، وعلي الحجار</p>
              </div>
            </div>
            <Link href="/genres/pop" className="text-xs text-cyan-400 hover:underline flex items-center gap-1 font-bold">
              <span>المزيد</span>
              <ChevronLeft className="w-4 h-4 rtl:rotate-180" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5">
            {(expandedSections["90s_nostalgia"] ? nostalgia90sTracks : nostalgia90sTracks.slice(0, 6)).map((track, idx) => (
              <TrackCard
                key={track.trackId}
                track={track}
                trackList={nostalgia90sTracks}
                viewMode="list"
                index={idx}
                onAddToPlaylist={(t) => {
                  setSelectedTrackForPlaylist(t);
                  setIsPlaylistModalOpen(true);
                }}
              />
            ))}
          </div>

          {nostalgia90sTracks.length > 6 && (
            <button
              onClick={() => toggleSection("90s_nostalgia")}
              className="mt-1 py-2 px-4 rounded-xl bg-[#161622] hover:bg-[#1e1e30] text-zinc-300 text-xs font-bold flex items-center justify-center gap-1.5 border border-white/[0.08] transition"
            >
              <span>{expandedSections["90s_nostalgia"] ? "عرض أقل" : `عرض المزيد من نوستالجيا التسعينات (${nostalgia90sTracks.length - 6}+)`}</span>
              {expandedSections["90s_nostalgia"] ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
          )}
        </section>
      )}

      {/* 7. Tarab Classics (طرب أصيل) */}
      {tarabTracks.length > 0 && (
        <section className="flex flex-col gap-4 bg-[#0d0d14]/70 p-4 sm:p-6 rounded-3xl border border-white/[0.08] shadow-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-yellow-500 to-amber-500 flex items-center justify-center shadow-md">
                <Mic2 className="w-4 h-4 text-zinc-950 font-black" />
              </div>
              <div>
                <h2 className="text-lg sm:text-xl font-black text-white">روائع الطرب الأصيل وسهرات الزمن الجميل</h2>
                <p className="text-[11px] text-zinc-400">أم كلثوم، عبد الحليم، فيروز، وردة، فريد الأطرش، طلال مداح، وصباح فخري</p>
              </div>
            </div>
            <Link href="/genres/tarab" className="text-xs text-amber-400 hover:underline flex items-center gap-1 font-bold">
              <span>قسم الطرب الكامل</span>
              <ChevronLeft className="w-4 h-4 rtl:rotate-180" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5">
            {(expandedSections["tarab"] ? tarabTracks : tarabTracks.slice(0, 6)).map((track, idx) => (
              <TrackCard
                key={track.trackId}
                track={track}
                trackList={tarabTracks}
                viewMode="list"
                index={idx}
                onAddToPlaylist={(t) => {
                  setSelectedTrackForPlaylist(t);
                  setIsPlaylistModalOpen(true);
                }}
              />
            ))}
          </div>

          {tarabTracks.length > 6 && (
            <button
              onClick={() => toggleSection("tarab")}
              className="mt-1 py-2 px-4 rounded-xl bg-[#161622] hover:bg-[#1e1e30] text-zinc-300 text-xs font-bold flex items-center justify-center gap-1.5 border border-white/[0.08] transition"
            >
              <span>{expandedSections["tarab"] ? "عرض أقل" : `عرض المزيد من أغاني الطرب (${tarabTracks.length - 6}+)`}</span>
              {expandedSections["tarab"] ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
          )}
        </section>
      )}

      {/* 8. Shaabi & Mahraganat (شعبي ومهرجانات) */}
      {shaabiTracks.length > 0 && (
        <section className="flex flex-col gap-4 bg-[#0d0d14]/70 p-4 sm:p-6 rounded-3xl border border-white/[0.08] shadow-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-pink-500 to-rose-500 flex items-center justify-center shadow-md">
                <Flame className="w-4 h-4 text-white font-black" />
              </div>
              <div>
                <h2 className="text-lg sm:text-xl font-black text-white">شعبيات ومهرجانات الشارع</h2>
                <p className="text-[11px] text-zinc-400">عصام صاصا، حسن شاكوش، حكيم، عدوية، البحراوي، مسلم، عنبة، وبيكا</p>
              </div>
            </div>
            <Link href="/genres/shaabi" className="text-xs text-rose-400 hover:underline flex items-center gap-1 font-bold">
              <span>المزيد</span>
              <ChevronLeft className="w-4 h-4 rtl:rotate-180" />
            </Link>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {(expandedSections["shaabi"] ? shaabiTracks : shaabiTracks.slice(0, 6)).map((track) => (
              <TrackCard
                key={track.trackId}
                track={track}
                trackList={shaabiTracks}
                viewMode="grid"
                onAddToPlaylist={(t) => {
                  setSelectedTrackForPlaylist(t);
                  setIsPlaylistModalOpen(true);
                }}
              />
            ))}
          </div>

          {shaabiTracks.length > 6 && (
            <button
              onClick={() => toggleSection("shaabi")}
              className="mt-1 py-2 px-4 rounded-xl bg-[#161622] hover:bg-[#1e1e30] text-zinc-300 text-xs font-bold flex items-center justify-center gap-1.5 border border-white/[0.08] transition"
            >
              <span>{expandedSections["shaabi"] ? "عرض أقل" : `عرض المزيد من الأغاني الشعبية والمهرجانات (${shaabiTracks.length - 6}+)`}</span>
              {expandedSections["shaabi"] ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
          )}
        </section>
      )}

      {/* 9. Arabic Rap & Trap (راب وهيب هوب) */}
      {rapTracks.length > 0 && (
        <section className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Radio className="w-5 h-5 text-purple-400" />
              <h2 className="text-lg sm:text-xl font-black text-white">راب وتراب المشهد العربي والعالمي</h2>
            </div>
            <Link href="/genres/rap" className="text-xs text-purple-400 hover:underline flex items-center gap-1 font-bold">
              <span>المزيد من الراب</span>
              <ChevronLeft className="w-4 h-4 rtl:rotate-180" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5">
            {(expandedSections["rap"] ? rapTracks : rapTracks.slice(0, 6)).map((track, idx) => (
              <TrackCard
                key={track.trackId}
                track={track}
                trackList={rapTracks}
                viewMode="list"
                index={idx}
                onAddToPlaylist={(t) => {
                  setSelectedTrackForPlaylist(t);
                  setIsPlaylistModalOpen(true);
                }}
              />
            ))}
          </div>

          {rapTracks.length > 6 && (
            <button
              onClick={() => toggleSection("rap")}
              className="mt-1 py-2 px-4 rounded-xl bg-[#161622] hover:bg-[#1e1e30] text-zinc-300 text-xs font-bold flex items-center justify-center gap-1.5 border border-white/[0.08] transition"
            >
              <span>{expandedSections["rap"] ? "عرض أقل" : `عرض المزيد من الراب (${rapTracks.length - 6}+)`}</span>
              {expandedSections["rap"] ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
          )}
        </section>
      )}

      {/* 10. Khaleeji & Iraqi (خليجي وعراقي) */}
      {khaleejiTracks.length > 0 && (
        <section className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Music className="w-5 h-5 text-emerald-400" />
              <h2 className="text-lg sm:text-xl font-black text-white">جلسات وطربيات خليجية وعراقية</h2>
            </div>
            <Link href="/genres/khaleeji" className="text-xs text-emerald-400 hover:underline flex items-center gap-1 font-bold">
              <span>المزيد</span>
              <ChevronLeft className="w-4 h-4 rtl:rotate-180" />
            </Link>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {(expandedSections["khaleeji"] ? khaleejiTracks : khaleejiTracks.slice(0, 6)).map((track) => (
              <TrackCard
                key={track.trackId}
                track={track}
                trackList={khaleejiTracks}
                viewMode="grid"
                onAddToPlaylist={(t) => {
                  setSelectedTrackForPlaylist(t);
                  setIsPlaylistModalOpen(true);
                }}
              />
            ))}
          </div>

          {khaleejiTracks.length > 6 && (
            <button
              onClick={() => toggleSection("khaleeji")}
              className="mt-1 py-2 px-4 rounded-xl bg-[#161622] hover:bg-[#1e1e30] text-zinc-300 text-xs font-bold flex items-center justify-center gap-1.5 border border-white/[0.08] transition"
            >
              <span>{expandedSections["khaleeji"] ? "عرض أقل" : `عرض المزيد من الخليجي والعراقي (${khaleejiTracks.length - 6}+)`}</span>
              {expandedSections["khaleeji"] ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
          )}
        </section>
      )}

      {/* 11. Chill & Calm Music (موسيقى هادئة) */}
      {calmTracks.length > 0 && (
        <section className="flex flex-col gap-4 bg-[#0d0d14]/70 p-4 sm:p-6 rounded-3xl border border-white/[0.08] shadow-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Coffee className="w-5 h-5 text-teal-400" />
              <h2 className="text-lg sm:text-xl font-black text-white">موسيقى هادئة ومعزوفات بيانو وعود</h2>
            </div>
            <Link href="/genres/calm" className="text-xs text-teal-400 hover:underline flex items-center gap-1 font-bold">
              <span>المزيد من الهدوء</span>
              <ChevronLeft className="w-4 h-4 rtl:rotate-180" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5">
            {(expandedSections["calm"] ? calmTracks : calmTracks.slice(0, 6)).map((track, idx) => (
              <TrackCard
                key={track.trackId}
                track={track}
                trackList={calmTracks}
                viewMode="list"
                index={idx}
                onAddToPlaylist={(t) => {
                  setSelectedTrackForPlaylist(t);
                  setIsPlaylistModalOpen(true);
                }}
              />
            ))}
          </div>
        </section>
      )}

      {/* 12. Featured Artists Directory Showcase */}
      {artistsList.length > 0 && (
        <section className="flex flex-col gap-4 bg-[#0d0d14]/70 p-4 sm:p-6 rounded-3xl border border-white/[0.08] shadow-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Mic2 className="w-5 h-5 text-emerald-400" />
              <h2 className="text-lg sm:text-xl font-black text-white">أبرز نجوم الغناء والمطربين</h2>
            </div>
            <Link href="/artists" className="text-xs text-emerald-400 hover:underline flex items-center gap-1 font-bold">
              <span>كل المطربين ({artistsList.length})</span>
              <ChevronLeft className="w-4 h-4 rtl:rotate-180" />
            </Link>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3.5">
            {(expandedSections["artists"] ? artistsList : artistsList.slice(0, 12)).map((artist) => (
              <ArtistCard key={artist.id} artist={artist} />
            ))}
          </div>

          {artistsList.length > 12 && (
            <button
              onClick={() => toggleSection("artists")}
              className="mt-2 py-2 px-4 rounded-xl bg-[#161622] hover:bg-[#1e1e30] text-zinc-300 text-xs font-bold flex items-center justify-center gap-1.5 border border-white/[0.08] transition"
            >
              <span>{expandedSections["artists"] ? "عرض أقل" : `عرض المزيد من النجوم (${artistsList.length - 12}+)`}</span>
              {expandedSections["artists"] ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
          )}
        </section>
      )}

      {/* 13. Curated Playlists Showcase */}
      {playlistsList.length > 0 && (
        <section className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Disc3 className="w-5 h-5 text-indigo-400" />
              <h2 className="text-lg sm:text-xl font-black text-white">قوائم تشغيل مختارة</h2>
            </div>
            <Link href="/library" className="text-xs text-indigo-400 hover:underline flex items-center gap-1 font-bold">
              <span>مكتبة القوائم</span>
              <ChevronLeft className="w-4 h-4 rtl:rotate-180" />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {playlistsList.map((pl) => (
              <Link
                key={pl.id}
                href={`/playlists/${pl.id}`}
                className="group p-4 rounded-3xl bg-[#121218]/60 hover:bg-[#181822] border border-white/[0.08] hover:border-emerald-500/30 transition-all duration-300 shadow-lg flex items-center gap-4 cursor-pointer"
              >
                <div className="w-16 h-16 rounded-2xl overflow-hidden bg-zinc-900 shrink-0 border border-white/[0.08]">
                  {pl.coverUrl ? (
                    <img src={pl.coverUrl} alt={pl.name} className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-500" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Disc3 className="w-8 h-8 text-zinc-600" />
                    </div>
                  )}
                </div>

                <div className="min-w-0 flex-1 text-right">
                  <h4 className="text-sm font-bold text-white group-hover:text-emerald-300 transition-colors truncate">
                    {pl.name}
                  </h4>
                  <p className="text-xs text-zinc-400 line-clamp-1 mt-0.5">{pl.description || "قائمة مختارة"}</p>
                  <span className="text-[10px] text-emerald-400 font-semibold mt-1.5 inline-block bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20">
                    {pl.isSystem ? "رسمية من نغم" : "قائمة مخصصة"}
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* Playlist Modal */}
      <PlaylistModal
        isOpen={isPlaylistModalOpen}
        onClose={() => setIsPlaylistModalOpen(false)}
        selectedTrack={selectedTrackForPlaylist}
        onPlaylistCreated={loadData}
      />
    </div>
  );
}

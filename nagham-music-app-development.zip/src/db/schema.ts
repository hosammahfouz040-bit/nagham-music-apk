import { pgTable, text, serial, integer, boolean, timestamp, uniqueIndex } from "drizzle-orm/pg-core";

export const cachedTracks = pgTable(
  "cached_tracks",
  {
    id: serial("id").primaryKey(),
    trackId: text("track_id").notNull().unique(),
    title: text("title").notNull(),
    artistName: text("artist_name").notNull(),
    albumName: text("album_name").default(""),
    artworkUrl: text("artwork_url").default(""),
    previewUrl: text("preview_url").notNull(),
    fullStreamUrl: text("full_stream_url"),
    youtubeVideoId: text("youtube_video_id"),
    isFullPlayable: boolean("is_full_playable").default(false),
    fullDurationSeconds: integer("full_duration_seconds"),
    playbackType: text("playback_type").default("preview_only"), // 'full_stream' | 'youtube_official' | 'preview_only' | 'external_only'
    externalAppleMusicUrl: text("external_apple_music_url"),
    externalDeezerUrl: text("external_deezer_url"),
    externalSpotifyUrl: text("external_spotify_url"),
    externalYoutubeUrl: text("external_youtube_url"),
    externalAnghamiUrl: text("external_anghami_url"),
    durationSeconds: integer("duration_seconds").default(30),
    genre: text("genre").default("عام"),
    genreCategory: text("genre_category").default("pop"), // tarab, shaabi, mahraganat, romantic, rap, rock, pop, calm, world, khaleeji
    language: text("language").default("arabic"), // 'arabic' | 'international'
    releaseDate: text("release_date").default(""),
    lyrics: text("lyrics"),
    playCount: integer("play_count").default(0),
    isFeatured: boolean("is_featured").default(false),
    isTrending: boolean("is_trending").default(false),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex("track_id_idx").on(table.trackId),
  ]
);

export const artists = pgTable("artists", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  nameAr: text("name_ar"),
  imageUrl: text("image_url").notNull(),
  bio: text("bio").default(""),
  genre: text("genre").default("موسيقى"),
  genreCategory: text("genre_category").default("pop"),
  language: text("language").default("arabic"),
  monthlyListeners: text("monthly_listeners").default("1M+"),
  isPopular: boolean("is_popular").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const albums = pgTable("albums", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  artistName: text("artist_name").notNull(),
  artistId: text("artist_id"),
  coverUrl: text("cover_url").notNull(),
  releaseYear: text("release_year").default("2024"),
  genre: text("genre").default("موسيقى"),
  genreCategory: text("genre_category").default("pop"),
  language: text("language").default("arabic"),
  totalTracks: integer("total_tracks").default(10),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const playlists = pgTable("playlists", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").default(""),
  coverUrl: text("cover_url").default(""),
  isSystem: boolean("is_system").default(false),
  genreCategory: text("genre_category"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const playlistItems = pgTable("playlist_items", {
  id: serial("id").primaryKey(),
  playlistId: text("playlist_id").notNull(),
  trackId: text("track_id").notNull(),
  title: text("title").notNull(),
  artistName: text("artist_name").notNull(),
  albumName: text("album_name").default(""),
  artworkUrl: text("artwork_url").default(""),
  previewUrl: text("preview_url").notNull(),
  youtubeVideoId: text("youtube_video_id"),
  fullStreamUrl: text("full_stream_url"),
  isFullPlayable: boolean("is_full_playable").default(false),
  fullDurationSeconds: integer("full_duration_seconds"),
  playbackType: text("playback_type").default("preview_only"),
  durationSeconds: integer("duration_seconds").default(30),
  position: integer("position").default(0),
  addedAt: timestamp("added_at").defaultNow().notNull(),
});

export const favorites = pgTable(
  "favorites",
  {
    id: serial("id").primaryKey(),
    trackId: text("track_id").notNull().unique(),
    title: text("title").notNull(),
    artistName: text("artist_name").notNull(),
    albumName: text("album_name").default(""),
    artworkUrl: text("artwork_url").default(""),
    previewUrl: text("preview_url").notNull(),
    youtubeVideoId: text("youtube_video_id"),
    fullStreamUrl: text("full_stream_url"),
    isFullPlayable: boolean("is_full_playable").default(false),
    fullDurationSeconds: integer("full_duration_seconds"),
    playbackType: text("playback_type").default("preview_only"),
    durationSeconds: integer("duration_seconds").default(30),
    genre: text("genre").default(""),
    genreCategory: text("genre_category").default("pop"),
    language: text("language").default("arabic"),
    externalAppleMusicUrl: text("external_apple_music_url"),
    externalDeezerUrl: text("external_deezer_url"),
    externalSpotifyUrl: text("external_spotify_url"),
    externalYoutubeUrl: text("external_youtube_url"),
    externalAnghamiUrl: text("external_anghami_url"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex("fav_track_id_idx").on(table.trackId),
  ]
);

export const listeningHistory = pgTable("listening_history", {
  id: serial("id").primaryKey(),
  trackId: text("track_id").notNull(),
  title: text("title").notNull(),
  artistName: text("artist_name").notNull(),
  albumName: text("album_name").default(""),
  artworkUrl: text("artwork_url").default(""),
  previewUrl: text("preview_url").notNull(),
  durationSeconds: integer("duration_seconds").default(30),
  genre: text("genre").default(""),
  playedAt: timestamp("played_at").defaultNow().notNull(),
});

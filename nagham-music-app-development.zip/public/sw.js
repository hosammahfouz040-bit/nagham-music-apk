const CACHE_NAME = "nagham-cache-v2.1";
const AUDIO_CACHE = "nagham-audio-v2.1";
const API_CACHE = "nagham-api-v2.1";

const PRECACHE_ASSETS = [
  "/",
  "/manifest.json",
  "/data/catalog.json",
  "/icons/icon-192.png",
  "/icons/icon-512.png",
  "/genres",
  "/artists",
  "/albums",
  "/library",
  "/search",
  "/download",
];

// Install Event - Pre-cache core shell
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log("[ServiceWorker] Pre-caching core shell for offline use");
      return cache.addAll(PRECACHE_ASSETS).catch((err) => {
        console.warn("[ServiceWorker] Pre-cache partial fail:", err);
      });
    })
  );
  self.skipWaiting();
});

// Activate Event - Clean old caches
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (![CACHE_NAME, AUDIO_CACHE, API_CACHE].includes(key)) {
            console.log("[ServiceWorker] Removing old cache:", key);
            return caches.delete(key);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// Fetch Event - Offline first / Stale-while-revalidate strategy
self.addEventListener("fetch", (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Skip non-GET or chrome extension requests
  if (request.method !== "GET" || url.protocol.startsWith("chrome-extension")) {
    return;
  }

  // 0. EXCLUDE APK downloads completely so native browser download works seamlessly!
  if (
    url.pathname.endsWith(".apk") ||
    url.pathname.includes("download-apk") ||
    url.pathname.includes("/downloads/")
  ) {
    return; // Pass through directly to network/native downloader
  }

  // 1. Audio stream caching (AAC, M4A, MP3)
  if (
    url.pathname.endsWith(".m4a") ||
    url.pathname.endsWith(".mp3") ||
    url.pathname.endsWith(".aac") ||
    url.hostname.includes("audio-ssl.itunes.apple.com") ||
    url.hostname.includes("dzcdn.net")
  ) {
    event.respondWith(
      caches.open(AUDIO_CACHE).then((cache) => {
        return cache.match(request).then((cachedResponse) => {
          if (cachedResponse) {
            return cachedResponse;
          }
          return fetch(request)
            .then((networkResponse) => {
              if (networkResponse && networkResponse.status === 200) {
                cache.put(request, networkResponse.clone());
              }
              return networkResponse;
            })
            .catch(() => {
              return cachedResponse || new Response(new ArrayBuffer(0), { status: 200 });
            });
        });
      })
    );
    return;
  }

  // 2. API caching (tracks, artists, playlists, stats, genres)
  if (url.pathname.startsWith("/api/")) {
    event.respondWith(
      caches.open(API_CACHE).then((cache) => {
        return fetch(request)
          .then((networkResponse) => {
            if (networkResponse && networkResponse.status === 200) {
              cache.put(request, networkResponse.clone());
            }
            return networkResponse;
          })
          .catch(() => {
            // Offline fallback for API
            return cache.match(request).then((cachedResponse) => {
              if (cachedResponse) {
                return cachedResponse;
              }
              return new Response(
                JSON.stringify({
                  success: true,
                  offline: true,
                  message: "أنت في وضع عدم الاتصال",
                  data: [],
                }),
                {
                  headers: { "Content-Type": "application/json" },
                }
              );
            });
          });
      })
    );
    return;
  }

  // 3. Navigation requests (HTML pages)
  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request)
        .then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const copy = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
          }
          return networkResponse;
        })
        .catch(() => {
          return caches.match(request).then((cachedResponse) => {
            if (cachedResponse) return cachedResponse;
            return caches.match("/");
          });
        })
    );
    return;
  }

  // 4. Static assets (Images, CSS, JS, Fonts)
  event.respondWith(
    caches.match(request).then((cachedResponse) => {
      if (cachedResponse) {
        fetch(request)
          .then((networkResponse) => {
            if (networkResponse && networkResponse.status === 200) {
              caches.open(CACHE_NAME).then((cache) => cache.put(request, networkResponse));
            }
          })
          .catch(() => {});
        return cachedResponse;
      }

      return fetch(request)
        .then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const copy = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
          }
          return networkResponse;
        })
        .catch(() => {
          if (request.destination === "image") {
            return new Response(
              '<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100"><rect width="100" height="100" fill="#181822"/><text x="50" y="55" fill="#10b981" font-size="14" text-anchor="middle">نغم</text></svg>',
              { headers: { "Content-Type": "image/svg+xml" } }
            );
          }
        });
    })
  );
});
